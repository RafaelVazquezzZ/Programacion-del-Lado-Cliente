import express from 'express';
import cors from 'cors';

const app = express();

app.use(cors({
  origin: '*'
}));

/*
  ESCENARIO 3
  */
app.get('/caos/truncado', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.write('{ "id": 1, "nombre": "Miel" ');
  res.destroy();
});

app.listen(3000, () => {
  console.log('Mock server (escenario 3) en http://localhost:3000');
});

app.get('/productos', (req, res) => {
  res.json([
    { id: 1, nombre: 'Miel', precio: 120 },
    { id: 2, nombre: 'Café', precio: 90 }
  ]);
});

app.get('/productos/1', (req, res) => {
  res.json({ id: 1, nombre: 'Miel', precio: 120 });
});

app.get('/productos-lento', (req, res) => {
  setTimeout(() => {
    res.json({ ok: true });
  }, 2500); // > 2 segundos
});