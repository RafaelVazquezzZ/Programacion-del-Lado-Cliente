import { BASE_URL, TIMEOUT_MS, LOG_LEVEL } from './config.js';

const LEVELS = ['DEBUG', 'INFO', 'WARN', 'ERROR'];

function shouldLog(level) {
  return LEVELS.indexOf(level) >= LEVELS.indexOf(LOG_LEVEL);
}

function log(level, message, meta = {}) {
  if (!shouldLog(level)) return;

  console.log(JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    message,
    ...meta
  }));
}

export async function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();
  const start = performance.now();
  const requestId = crypto.randomUUID();

  const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);

  const method = options.method ?? 'GET';
  const headers = sanitizeHeaders(options.headers);

  log('DEBUG', 'HTTP request started', {
    requestId,
    method,
    url,
    headers
  });

  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Accept': 'application/json',
        'X-Client-Version': '1.0',
        ...options.headers
      },
      signal: controller.signal
    });

    const durationMs = Math.round(performance.now() - start);

    const level =
      durationMs > 2000 ? 'WARN' :
      response.ok ? 'INFO' : 'ERROR';

    log(level, 'HTTP request completed', {
      requestId,
      method,
      url,
      status: response.status,
      durationMs,
      headers
    });


    return response;

  } catch (error) {
    const durationMs = Math.round(performance.now() - start);

    log('ERROR', 'HTTP request failed', {
      requestId,
      method,
      url,
      durationMs,
      headers,
      error: error.message
    });

    throw error;

  } finally {
    clearTimeout(timeoutId);
  }
}

function assertJsonResponse(response) {
  const contentType = response.headers.get('content-type');
    //VALIDAR CONTENT TYPE ANTES DE LA RESPUETA
  if (!contentType?.includes('application/json')) {
    throw new Error('Respuesta no es JSON');
  }
}

export async function listarProductos() {
  const response = await fetchWithTimeout(`${BASE_URL}/productos`);
  if (!response.ok) throw new Error(response.status);
  return response.json();
}


export async function obtenerProductoPorId(id) {
  const response = await fetchWithTimeout(`${BASE_URL}/productos/${id}`);

  if (response.status === 404) return null;
  if (!response.ok) throw new Error(response.status);

  assertJsonResponse(response);
  return response.json();
}

export async function crearProducto(producto, token) {
  const response = await fetchWithTimeout(`${BASE_URL}/productos`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token && {'Authorization': `Bearer ${token}`})    
    },
    body: JSON.stringify(producto)
  });
  
  if (!response.ok) {
  throw new Error(`HTTP ${response.status}`);
  }
  
  assertJsonResponse(response);
  return response.json();
}

function sanitizeHeaders(headers = {}) {
  const clean = { ...headers };

  if (clean.Authorization) {
    clean.Authorization = 'Bearer ***';
  }

  return clean;
}
