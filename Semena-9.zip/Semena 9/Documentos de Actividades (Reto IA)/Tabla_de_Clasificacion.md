Entregable — Clasificación de errores para Circuit Breaker

Clasificación inicial del estudiante

1. 503 Service Unavailable → FALLO
   Porque el servidor indica que no puede atender solicitudes.

2. 401 Unauthorized → IGNORAR
   Porque el problema es de autenticación del cliente.

3. Timeout de 30 segundos → FALLO
   Porque el servidor no respondió a tiempo.

4. 404 Not Found → IGNORAR
   Porque el recurso solicitado no existe, pero el servidor sí funciona.

5. Connection Refused → FALLO
   Porque el servidor no acepta conexiones en ese puerto.

6. 500 Internal Server Error → FALLO
   Porque ocurrió un error interno del servidor.

7. 429 Too Many Requests → IGNORAR
   Porque el servidor sigue funcionando pero limita al cliente.

8. 403 Forbidden → IGNORAR
   Porque el cliente no tiene permisos para acceder.

--------------------------------------------------

Corrección / evaluación de la IA

✅ Correctos:
- 503 → FALLO
- 401 → IGNORAR
- Timeout → FALLO
- 404 → IGNORAR
- Connection Refused → FALLO
- 500 → FALLO
- 429 → IGNORAR
- 403 → IGNORAR

Razonamiento desde la perspectiva del CLIENTE:

El Circuit Breaker debe abrirse únicamente cuando el error sugiere que el SERVIDOR o la RED tienen problemas temporales de disponibilidad.

Los errores:
- HTTP 500
- HTTP 503
- Timeout
- Connection Refused

indican fallos reales del servicio o de conectividad, por lo tanto cuentan como FALLO.

En cambio:
- HTTP 401
- HTTP 403
- HTTP 404
- HTTP 429

indican problemas relacionados con autenticación, permisos, recursos inexistentes o límites del cliente, pero no significan que el servidor esté caído. Por eso deben IGNORARSE para el Circuit Breaker.

--------------------------------------------------

Comentario sugerido para el código de _es_fallo_servidor(error)

# Se consideran fallos del servidor:
# - HTTP 500 Internal Server Error
# - HTTP 503 Service Unavailable
# - Timeouts
# - Connection Refused
#
# NO deben abrir el circuito:
# - HTTP 401 Unauthorized
# - HTTP 403 Forbidden
# - HTTP 404 Not Found
# - HTTP 429 Too Many Requests
#
# Regla general:
# El Circuit Breaker solo debe abrirse cuando el problema
# indica falla del SERVIDOR o de la RED, no del CLIENTE.