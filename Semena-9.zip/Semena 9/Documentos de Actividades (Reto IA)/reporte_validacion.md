# REPORTE DE VALIDACIÓN — CIRCUIT BREAKER

## Alumno
Rafael Vazquez

## Materia
Programación del Lado Cliente

## Tema
Patrón de resiliencia: Circuit Breaker

---

# Objetivo de la Validación

Validar el comportamiento del patrón Circuit Breaker bajo:

- operación normal,
- fallos consecutivos,
- recuperación automática,
- concurrencia,
- protección del backend,
- manejo diferenciado de errores cliente vs servidor.

---

# Configuración del Entorno de Pruebas

## Parámetros del Circuit Breaker

```python
umbral_fallos = 5
timeout_apertura = 2 segundos
```

---

## Mock del servidor

Se utilizó un `MockServidor` con tres modos de operación:

| Modo | Comportamiento |
|---|---|
| `normal` | Respuesta exitosa |
| `fallo_503` | Lanza `ServerFailureError` |
| `401` | Lanza `ClientFailureError` |

---

# Resultados de Casos de Prueba

| Caso | Descripción | Resultado Esperado | Resultado Observado | Estado |
|---|---|---|---|---|
| 1 | Estado inicial y operación normal | Circuito permanece CERRADO y contador = 0 | Correcto | ✅ PASÓ |
| 2 | Transición CERRADO → ABIERTO | Se abre exactamente en el fallo N | Correcto | ✅ PASÓ |
| 3 | Los errores 401 no abren el circuito | Permanece CERRADO | Correcto | ✅ PASÓ |
| 4 | Timeout ABIERTO → SEMIABIERTO | Cambia después del timeout | Correcto | ✅ PASÓ |
| 5 | Recuperación SEMIABIERTO → CERRADO | Cierra y reinicia contador | Correcto | ✅ PASÓ |
| 6 | Fallo en SEMIABIERTO → ABIERTO | Reabre circuito correctamente | Correcto | ✅ PASÓ |
| 7 | Concurrencia en SEMIABIERTO | Solo 1 request atraviesa el breaker | Correcto | ✅ PASÓ |

---

# Evidencia de Ejecución

## Salida obtenida

```text
🚀 INICIANDO TESTS

--- CASO 1 ---
✅ CASO 1 PASADO

--- CASO 2 ---
✅ CircuitOpenError correcto
✅ CASO 2 PASADO

--- CASO 3 ---
✅ CASO 3 PASADO

--- CASO 4 ---
Esperando timeout...
✅ CASO 4 PASADO

--- CASO 5 ---
✅ CASO 5 PASADO

--- CASO 6 ---
✅ CASO 6 PASADO

--- CASO 7 ---
Éxitos: 1
CircuitOpenErrors: 2
Peticiones servidor: 1
✅ CASO 7 PASADO

🎉 TODOS LOS TESTS PASARON
```

---

# Evidencia de Protección al Backend

## Antes de abrir el circuito

Durante los fallos iniciales:

```text
5 peticiones llegaron al servidor
```

porque el Circuit Breaker aún estaba en estado `CERRADO`.

---

## Después de abrir el circuito

Una vez abierto el breaker:

```text
las peticiones fueron bloqueadas inmediatamente
```

sin llegar al backend.

Esto evita:

- saturación del servidor,
- retries innecesarios,
- cascadas de fallos.

---

# Evidencia de Concurrencia (Caso 7)

Resultado obtenido:

```text
Éxitos: 1
CircuitOpenErrors: 2
Peticiones servidor: 1
```

Esto demuestra que:

- solo una petición atravesó el estado `SEMIABIERTO`,
- las otras dos fueron rechazadas inmediatamente,
- el lock protegió correctamente la ventana de recuperación,
- el backend quedó protegido de tráfico concurrente excesivo.

---

# Auditoría de Bugs

## BUG detectado — Coroutine nunca awaited

### Tipo

Bug async / manejo incorrecto de coroutines.

---

## Causa raíz

La implementación inicial del Circuit Breaker recibía un coroutine ya creado:

```python
await cb.ejecutar(
    mock.get("/api/inventario")
)
```

Cuando el circuito estaba abierto, `CircuitOpenError`
se lanzaba antes de ejecutar:

```python
await coro
```

dejando el coroutine sin consumir.

---

## Evidencia

Python mostraba:

```text
RuntimeWarning: coroutine 'MockServidor.get' was never awaited
```

---

## Impacto

Este bug puede provocar:

- warnings async,
- fuga de memoria,
- acumulación de coroutines huérfanos,
- comportamiento indefinido bajo carga concurrente.

---

## Fix aplicado

Se modificó la firma del método:

### Antes

```python
async def ejecutar(self, coro)
```

### Después

```python
async def ejecutar(self, fn, *args, **kwargs)
```

y ahora el coroutine solo se crea cuando el breaker permite tráfico:

```python
resultado = await fn(*args, **kwargs)
```

---

# Auditoría de los 5 Bugs Requeridos

| Bug | Resultado |
|---|---|
| BUG 1 — Timer fantasma | ✅ Protegido usando `time.monotonic()` |
| BUG 2 — Contador no resetea | ✅ Corregido |
| BUG 3 — Lock nunca libera | ✅ Protegido con `finally` |
| BUG 4 — Race condition en SEMIABIERTO | ✅ Corregido con lock + flag |
| BUG 5 — CircuitOpenError infla contador | ✅ Corregido usando excepción separada |

---

# Decisión de Diseño — Autenticación y Circuit Breaker

Las peticiones de autenticación NO deben depender del mismo Circuit Breaker principal del backend.

## Riesgo identificado

Si el breaker también bloquea:

```text
POST /api/auth/token
```

el sistema puede entrar en deadlock:

- no puede renovar el token,
- no puede recuperar sesión,
- no puede salir del estado de fallo.

---

## Decisión tomada

Las peticiones de autenticación deben:

- excluirse del breaker principal,
- o utilizar un breaker independiente con umbrales más tolerantes.

Esta decisión evita bloquear completamente el sistema de autenticación.

---

# Conclusión

La implementación final del Circuit Breaker:

- cumple correctamente los 7 casos de prueba,
- protege al backend bajo fallos,
- maneja concurrencia correctamente,
- diferencia errores cliente vs servidor,
- evita bugs async comunes,
- utiliza reloj monotónico correctamente,
- implementa recuperación segura mediante SEMIABIERTO.

El patrón quedó validado funcionalmente y auditado respecto a bugs comunes de resiliencia.