## =========
## Reto IA 1
## =========
(1) Descripción inicial del estudiante

“El circuito empieza siempre en cerrado y deja pasar peticiones.
Después se validan las peticiones y si son correctas pasa a abierto.
De abierto puede pasar a semiabierto para validar conexión o token.
Desde ahí puede volver a abierto o cerrado dependiendo de la validación.”

--------------------------------------------------

(2) Evaluación de la IA

- Correcto: desde SEMIABIERTO el sistema puede volver a ABIERTO o CERRADO según el resultado de la petición de prueba.
- Incompleto/incorrecto: los estados CERRADO y ABIERTO están invertidos.
- Pregunta socrática:
  “Si el servicio falla muchas veces seguidas, ¿qué estado debería bloquear temporalmente las llamadas?”

--------------------------------------------------

(3) Corrección del estudiante

“Entendí que estaba interpretando los estados al revés.
CERRADO significa operación normal y deja pasar peticiones.
ABIERTO bloquea temporalmente llamadas cuando hay muchos fallos.
SEMIABIERTO deja pasar pocas peticiones de prueba para validar recuperación.”

--------------------------------------------------

Versión final del diagrama en ASCII

CERRADO --(N fallos consecutivos / HTTP 500 / timeout)--> ABIERTO

ABIERTO --(timeout_apertura expiró)--> SEMIABIERTO

SEMIABIERTO --(petición de prueba exitosa)--> CERRADO

SEMIABIERTO --(petición de prueba fallida)--> ABIERTO

Errores que NO abren el circuito:
- HTTP 404
- Peticiones malformadas (400)


## =========
## Reto IA 5
## =========
# Reflexión y decisiones de arquitectura — Circuit Breaker

## Configuración implementada

La implementación del Circuit Breaker utiliza los siguientes valores:

- Umbral de fallos: 5 errores consecutivos
- Timeout de apertura: 60 segundos

Esta configuración busca equilibrar resiliencia y disponibilidad, evitando abrir el circuito por errores temporales aislados mientras se protege al backend de solicitudes repetitivas durante fallos reales.

---

# 1. Justificación de los umbrales elegidos

## ESCENARIO 1 — Reinicio programado de 45 segundos

El servidor de EcoMarket realiza un reinicio controlado de 45 segundos durante mantenimiento nocturno.

### Evaluación de la configuración

La configuración actual es conservadora porque:

- tolera varios errores antes de abrir el circuito
- espera un tiempo relativamente largo antes de volver a probar

### Consecuencias en el panel de EcoMarket

Durante el reinicio:

- los primeros cinco requests fallarán antes de abrir el circuito
- los operadores verán errores temporales
- una vez abierto, el Circuit Breaker evitará tráfico innecesario al backend

El timeout de 60 segundos es mayor que el tiempo real de mantenimiento (45 segundos), por lo que el sistema tardará un poco más de lo necesario en recuperarse.

### Decisión

Mantener 60 segundos es aceptable porque evita reintentos prematuros mientras el servidor aún se estabiliza.  
Sin embargo, para mantenimientos programados podría ajustarse temporalmente a 45–50 segundos para reducir tiempo de espera percibido.

---

## ESCENARIO 2 — Respuestas lentas (3 segundos)

El servidor responde correctamente con HTTP 200, pero tarda aproximadamente 3 segundos en responder.

### Evaluación de la configuración

La configuración actual es conservadora respecto a latencia porque el Circuit Breaker solo considera errores explícitos y no tiempos de respuesta lentos.

### Consecuencias en el panel de EcoMarket

Aunque no existan errores HTTP:

- la interfaz puede sentirse lenta
- algunas operaciones podrían parecer congeladas
- los usuarios podrían repetir acciones innecesariamente
- podrían acumularse requests pendientes

El Circuit Breaker probablemente no se activaría porque técnicamente el servidor sigue respondiendo correctamente.

### Decisión

Considero que respuestas excesivamente lentas sí deberían poder activar el Circuit Breaker cuando afectan la experiencia operativa.

Para esto implementaría:

- timeout HTTP de 2 segundos
- clasificación de timeout como fallo
- degradación elegante mediante mensajes temporales o datos cacheados

Esto prioriza disponibilidad percibida y evita bloquear la interfaz esperando respuestas lentas.

---

## ESCENARIO 3 — Pérdida temporal de conectividad del cliente

Los operadores pierden conexión WiFi durante 10 segundos, pero el backend continúa funcionando normalmente.

### Evaluación de la configuración

La configuración puede resultar agresiva frente a fallos locales de red, ya que múltiples errores consecutivos podrían abrir el circuito aunque el servidor esté sano.

### Consecuencias en el panel de EcoMarket

Si todos los errores de red se contabilizan igual:

- el Circuit Breaker podría abrirse innecesariamente
- el sistema seguiría rechazando requests incluso después de recuperar conectividad
- el operador percibiría una caída completa del sistema

### Decisión

El interceptor HTTP debería diferenciar:

- errores locales de conectividad
- errores reales del backend

No todos los errores de red del cliente deberían incrementar el contador del Circuit Breaker.

---

# 2. Límites del Circuit Breaker

El patrón Circuit Breaker mejora resiliencia y evita cascadas de fallos, pero no resuelve todos los problemas del sistema.

Limitaciones identificadas:

- No corrige problemas de red del cliente.
- No acelera automáticamente respuestas lentas.
- No evita caídas completas del backend.
- No reemplaza mecanismos de retry o cache.
- No distingue por sí solo entre errores locales y errores del servidor.
- No resuelve problemas de autenticación o expiración de tokens.
- Puede generar falsos positivos si los umbrales son demasiado agresivos.

Por esta razón, el sistema separa responsabilidades entre distintos componentes:

| Componente | Responsabilidad |
|---|---|
| CircuitBreaker | Abrir/cerrar el circuito y controlar solicitudes |
| HTTP Interceptor | Detectar y clasificar errores HTTP y de red |
| TokenManager | Gestionar autenticación y renovación de tokens |

Esta separación mejora mantenibilidad, claridad arquitectónica y capacidad de pruebas.

---

# 3. Decisión sobre respuestas lentas (ESCENARIO 2)

Se decidió que respuestas excesivamente lentas sí deben poder activar el Circuit Breaker cuando afectan la experiencia de usuario y la operación del sistema.

Aunque el backend responda con HTTP 200, tiempos de respuesta muy altos pueden:

- degradar la experiencia del operador
- bloquear operaciones importantes
- consumir recursos innecesariamente
- generar acumulación de requests pendientes

## Implementación propuesta

Para manejar este escenario se propone:

- definir un timeout HTTP máximo de 2 segundos
- considerar timeout como fallo del Circuit Breaker
- mantener degradación elegante en la interfaz
- mostrar mensajes temporales o información cacheada cuando el servicio no responda dentro del tiempo esperado

Con esto se mejora la disponibilidad percibida y se evita que la aplicación permanezca bloqueada esperando respuestas lentas.