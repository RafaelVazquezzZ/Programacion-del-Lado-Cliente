class APIError(Exception):
    """Error genérico de la API"""
    pass