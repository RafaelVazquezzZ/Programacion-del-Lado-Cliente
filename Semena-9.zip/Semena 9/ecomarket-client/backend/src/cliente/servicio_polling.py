# ==========================================================
# TRAZA SSE — EcoMarket (Cliente async con aiohttp)
# Basado en ServicioPolling (Semana 4 → transición a SSE)
# ==========================================================

# CONTEXTO:
# En Semana 4, este cliente consulta /productos cada cierto intervalo,
# usando ETag para detectar cambios (If-None-Match).
# En SSE, eliminamos ese ciclo: el servidor empuja cambios automáticamente.

# ==========================================================
# t=0s — CONEXIÓN INICIAL
# ==========================================================

# Cliente → Servidor:
# GET /productos/stream   (nuevo endpoint SSE)
# Accept: text/event-stream

# Servidor → Cliente:
# HTTP/1.1 200 OK
# Content-Type: text/event-stream

# DIFERENCIA CLAVE:
# - En polling: se cerraba la conexión cada request
# - En SSE: la conexión queda ABIERTA

# ==========================================================
# t=2s — EVENTO 1 (CAMBIO DE PRODUCTO)
# ==========================================================

# Servidor envía (stream):
# id:1
# event:producto-actualizado
# data:{"producto":"A01","precio":47}
#
# \n  ← fin del mensaje

# Cliente (equivalente a _consultar()):
# - Lee línea por línea desde el stream
# - Construye el evento
# - Detecta fin con línea vacía (\n\n)
# - Procesa el JSON (como antes con resp.json())

# Estado interno:
# last_event_id = 1

# ==========================================================
# t=8s — EVENTO 2 (STOCK CRÍTICO)
# ==========================================================

# Servidor:
# id:2
# event:stock-critico
# data:{"producto":"B07","stock":1}
#
# \n

# Cliente:
# - Procesa evento
# - Podría imprimir: "Cambios detectados"
# - Ya NO usa ETag → ahora usa id

# Estado:
# last_event_id = 2

# ==========================================================
# t=15s — KEEP-ALIVE
# ==========================================================

# Servidor:
# : ping
#
# \n

# Cliente:
# - Detecta ":" → comentario
# - NO ejecuta lógica
# - Mantiene conexión viva

# Estado:
# last_event_id sigue siendo 2

# ==========================================================
# t=20s — EVENTO 3
# ==========================================================

# Servidor:
# id:3
# event:producto-actualizado
# data:{"producto":"A01","precio":45}
#
# \n

# Cliente:
# - Procesa evento como antes

# Estado:
# last_event_id = 3

# ==========================================================
# t=25s — ERROR DE RED
# ==========================================================

# La conexión SSE se cae

# Cliente:
# - Detecta excepción (como en try/except actual)
# - Espera retry (≈3 segundos)

# ==========================================================
# t=28s — RECONEXIÓN
# ==========================================================

# Cliente → Servidor:
# GET /productos/stream
# Accept: text/event-stream
# Last-Event-ID: 3

# IMPORTANCIA:
# - Reemplaza el uso de ETag
# - Permite continuar desde el último evento recibido

# Servidor:
# - Envía eventos desde id=4 en adelante

# ==========================================================
# DIFERENCIA CON TU POLLING ACTUAL
# ==========================================================

# POLLING (tu código actual):
# - Usa intervalo dinámico (5–60s)
# - Usa ETag para evitar descargar datos innecesarios
# - Muchas peticiones HTTP

# SSE:
# - Una sola conexión persistente
# - El servidor envía datos solo cuando hay cambios
# - No se necesita intervalo ni sleep()

# ==========================================================
# CONCLUSIÓN
# ==========================================================

# SSE reduce peticiones vacías porque elimina el ciclo de
# consulta periódica (asyncio.sleep), enviando datos únicamente
# cuando hay cambios en el servidor.

# En lugar de preguntar constantemente (polling), el cliente
# permanece escuchando y el servidor empuja los eventos.

import asyncio
import aiohttp

BASE_URL = "http://localhost:3000"
TIMEOUT = aiohttp.ClientTimeout(total=5)


class ServicioPolling:

    def __init__(self, endpoint="/productos"):
        self.endpoint = endpoint
        self.intervalo_actual = 5
        self.intervalo_min = 5
        self.intervalo_max = 60
        self.ultimo_etag = None
        self._activo = False

    async def _consultar(self):
        headers = {}

        # Agregar ETag si existe
        if self.ultimo_etag:
            headers["If-None-Match"] = self.ultimo_etag

        try:
            async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
                async with session.get(
                    f"{BASE_URL}{self.endpoint}",
                    headers=headers
                ) as resp:

                    # Caso cambios detectados
                    if resp.status == 200:

                        print("Cambios detectados")

                        # Guardar nuevo ETag
                        etag = resp.headers.get("ETag")
                        if etag:
                            self.ultimo_etag = etag

                        # Disminuir intervalo
                        self.intervalo_actual = max(
                            self.intervalo_min,
                            self.intervalo_actual - 5
                        )

                    # Caso sin cambios
                    elif resp.status == 304:

                        print("Sin cambios")

                        # Aumentar intervalo
                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

                    # Otros errores HTTP
                    else:
                        print(f"Error HTTP {resp.status}")
                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

        except Exception as e:
            print(f"Error en polling: {e}")

            # Aumentar intervalo en caso de fallo
            self.intervalo_actual = min(
                self.intervalo_max,
                self.intervalo_actual + 5
            )

    async def iniciar(self):
        self._activo = True

        while self._activo:
            await self._consultar()
            await asyncio.sleep(self.intervalo_actual)

    def detener(self):
        self._activo = False