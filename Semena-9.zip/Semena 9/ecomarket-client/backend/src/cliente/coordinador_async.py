import asyncio
import aiohttp
from cliente.excepciones import APIError

# ================= Timeout individual por petición ================= 

async def fetch_with_timeout(session, url, timeout):
    try:
        async with asyncio.timeout(timeout):
            async with session.get(url) as resp:

                if resp.status == 401:
                    raise PermissionError("No autorizado")

                if resp.status >= 400:
                    raise APIError(f"HTTP {resp.status}")

                return await resp.json()

    except asyncio.TimeoutError:
        print(f"[Timeout] {url}")
        return None

    except PermissionError:
        raise

    except Exception as e:
        print(f"[Error] {url}: {e}")
        return None
    
# =================  Cancelación de tareas en grupo ================= 
async def cancel_remaining(tasks):

    for t in tasks:
        if not t.done():
            t.cancel()

    for t in tasks:
        try:
            await t

        except asyncio.CancelledError:
            pass

        except Exception:
            pass
import asyncio
import aiohttp
from cliente.excepciones import APIError

# ================= Timeout individual por petición ================= 

async def fetch_with_timeout(session, url, timeout):
    try:
        async with asyncio.timeout(timeout):
            async with session.get(url) as resp:

                if resp.status == 401:
                    raise PermissionError("No autorizado")

                if resp.status >= 400:
                    raise APIError(f"HTTP {resp.status}")

                return await resp.json()

    except asyncio.TimeoutError:
        print(f"[Timeout] {url}")
        return None

    except PermissionError:
        raise

    except Exception as e:
        print(f"[Error] {url}: {e}")
        return None
    
# =================  Cancelación de tareas en grupo ================= 
async def cancel_remaining(tasks):

    for t in tasks:
        if not t.done():
            print(f"[Cancelando] {t.get_name()}")
            t.cancel()

    for t in tasks:
        try:
            await t
        except asyncio.CancelledError:
            print(f"[Cancelada] {t.get_name()}")
        except PermissionError:
            print(f"[Ignorada excepción 401] {t.get_name()}")
        except Exception as e:
            print(f"[Excepción ignorada] {t.get_name()} -> {e}")

# ================= Cargar con prioridad (procesar resultados conforme llegan) ================= 
async def cargar_con_prioridad(session):

    urls = {
        "productos": "http://localhost:8000/productos",
        "categorias": "http://localhost:8000/categorias",
        "perfil": "http://localhost:8000/perfil",
        "notificaciones": "http://localhost:8000/notificaciones"
    }

    timeouts = {
        "productos": 5,
        "categorias": 3,
        "perfil": 5,
        "notificaciones": 4
    }

    async def named_fetch(name):
        result = await fetch_with_timeout(session, urls[name], timeouts[name])
        return name, result

    tasks = [
        asyncio.create_task(named_fetch(name), name=name)
        for name in urls
    ]

    resultados = {}
    cancelar = False

    try:
        for fut in asyncio.as_completed(tasks):

            try:
                name, result = await fut

                resultados[name] = result

                if result is not None:
                    print(f"[Recibido] {name}")

                if name == "perfil" and result is None:
                    print("❌ Perfil inválido → cancelar")
                    cancelar = True
                    break

            except PermissionError:
                print("❌ Perfil 401 → cancelar todo")
                cancelar = True
                break


    finally:
        if cancelar:
            await cancel_remaining(tasks)

    return resultados

async def test_cancelacion(session):
    print("\n=== Test Cancelación por 401 ===")

    urls = {
        "productos": "http://localhost:8000/productos",
        "perfil": "http://localhost:8000/perfil",
        "notificaciones": "http://localhost:8000/notificaciones"
    }

    tasks = {
        name: asyncio.create_task(fetch_with_timeout(session, url, 5))
        for name, url in urls.items()
    }

    try:
        for fut in asyncio.as_completed(tasks.values()):
            await fut
    except PermissionError:
        print("❌ Perfil 401 → cancelando tareas restantes")
        await cancel_remaining(tasks.values())

# ================= Cargar con prioridad (procesar resultados conforme llegan) ================= 
async def cargar_con_prioridad(session):

    urls = {
        "productos": "http://localhost:8000/productos",
        "categorias": "http://localhost:8000/categorias",
        "perfil": "http://localhost:8000/perfil",
        "notificaciones": "http://localhost:8000/notificaciones"
    }

    timeouts = {
        "productos": 5,
        "categorias": 3,
        "perfil": 5,
        "notificaciones": 4
    }

    async def named_fetch(name):
        result = await fetch_with_timeout(session, urls[name], timeouts[name])
        return name, result

    tasks = [
        asyncio.create_task(named_fetch(name), name=name)
        for name in urls
    ]

    resultados = {}
    cancelar = False

    try:
        for fut in asyncio.as_completed(tasks):

            try:
                name, result = await fut

                resultados[name] = result

                if result is not None:
                    print(f"[Recibido] {name}")

                if name == "perfil" and result is None:
                    print("❌ Perfil inválido → cancelar")
                    cancelar = True
                    break

            except PermissionError:
                print("❌ Perfil 401 → cancelar todo")
                cancelar = True
                break


    finally:
        if cancelar:
            await cancel_remaining(tasks)

    return resultados
async def test_timeout_individual(session):
    print("\n=== Test Timeout Individual ===")

    urls = [
        ("productos", "http://localhost:8000/productos", 5),
        ("categorias", "http://localhost:8000/categorias", 3),
        ("perfil", "http://localhost:8000/perfil", 5),
        ("notificaciones", "http://localhost:8000/notificaciones", 4)
    ]

    tasks = [
        fetch_with_timeout(session, url, timeout)
        for _, url, timeout in urls
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    for (name, _, _), result in zip(urls, results):
        print(name, "→", "OK" if result else "None")

async def main():

    async with aiohttp.ClientSession() as session:

        # Estrategia 1
        await test_timeout_individual(session)

        # Estrategia 2
        await test_cancelacion(session)

        # Estrategia 3
        print("\n=== Test Prioridad ===")
        resultados = await cargar_con_prioridad(session)

        print("\n=== Resultados finales ===")
        for k, v in resultados.items():
            print(k, "→", "OK" if v else "None")



if __name__ == "__main__":
    asyncio.run(main())