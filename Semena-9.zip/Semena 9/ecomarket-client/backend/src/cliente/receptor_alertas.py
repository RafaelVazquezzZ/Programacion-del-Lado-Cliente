import asyncio
import httpx
import json
from datetime import datetime


class ReceptorAlertas:
       #ACTIVIDAD 3 Semana 6
    """
    RECEPTOR ALERTAS ECOMARKET — Decisiones de arquitectura (cliente)

    Escenario A:
    SSE elegido sobre polling porque con 10k usuarios, polling cada 1s genera ~600k requests/min,
    de las cuales >99% están vacías. SSE mantiene 1 conexión persistente por cliente (~10k conexiones)
    y solo envía datos cuando hay cambios, reduciendo carga y latencia.

    Escenario B:
    Polling obligatorio ya que el servidor legacy no soporta streaming. SSE no es viable sin modificar backend.
    Se acepta el costo de ~60 req/min por cliente y overhead de headers HTTP.

    Escenario C:
    Polling preferido en red inestable, ya que conexiones persistentes SSE se rompen frecuentemente,
    generando overhead de reconexión. Sin embargo, SSE podría recuperar eventos con Last-Event-ID,
    mientras polling puede perderlos.

    Escenario D:
    WebSocket elegido por comunicación bidireccional en tiempo real. SSE requeriría fetch adicional,
    incrementando conexiones y latencia. WebSocket permite full-duplex sobre una sola conexión TCP.
    """
    #ACTIVIDAD 2 Semana 6
    """
    Cliente SSE para EcoMarket

    DECISIONES DE DISEÑO (Trade-offs):
    --------------------------------
    ETAPA 1:
    - Se usa httpx async para mantener consistencia con cliente anterior
    - Timeout de 30s por conexión (no por evento)

    ETAPA 2:
    - Buffer como lista de líneas para ensamblar mensajes SSE
    - Se procesa hasta encontrar línea vacía
    - Se simulan eventos porque sse.dev no envía tipos reales

    ETAPA 3:
    - Reconexión con Last-Event-ID
    - Backoff exponencial para evitar saturar servidor
    - Límite de 5 intentos para evitar loops infinitos
    """
    def __init__(self, url):
        self.url = url
        self.ultimo_id = None
        self.retry_ms = 3000
        self.running = True
        self.intentos = 0
        self.max_intentos = 5

        self.contador_eventos = 0

    def timestamp(self):
        return datetime.now().strftime("%H:%M:%S")

    async def conectar(self):
        headers = {
            "Accept": "text/event-stream"
        }

        if self.ultimo_id:
            headers["Last-Event-ID"] = self.ultimo_id

        print(f"[{self.timestamp()}] Conectando... Last-Event-ID={self.ultimo_id}")

        # FIX: usar timeout simple para que funcione con sse.dev
        timeout = httpx.Timeout(30.0)

        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("GET", self.url, headers=headers) as response:

                print(f"[{self.timestamp()}] STATUS: {response.status_code}")

                if response.status_code == 204:
                    print("204 No Content → Fin del stream")
                    self.running = False
                    return

                buffer = []


        
                async for line in response.aiter_lines():
                    if not self.running:
                        print("Detención solicitada.")
                        return
                    self.contador_eventos += 1
                    if self.contador_eventos == 5:
                        raise httpx.ReadError("Simulación corte stream")
                    print(f"[{self.timestamp()}] RAW: {line}")

                    if line == "":
                        if buffer:
                            await self.safe_procesar_evento(buffer)
                            buffer = []
                    else:
                        buffer.append(line)

                if buffer:
                    await self.safe_procesar_evento(buffer)

    async def safe_procesar_evento(self, buffer):
        try:
            await self.procesar_evento(buffer)
        except Exception as e:
            print(f"[{self.timestamp()}] Error en handler: {e}")

    async def procesar_evento(self, buffer):
        event = "message"
        data = ""
        event_id = None

        for line in buffer:
            if line.startswith("id:"):
                event_id = line.replace("id:", "").strip()

            elif line.startswith("event:"):
                event = line.replace("event:", "").strip()

            elif line.startswith("data:"):
                data += line.replace("data:", "").strip()

            elif line.startswith("retry:"):
                try:
                    self.retry_ms = int(line.replace("retry:", "").strip())
                    print(f"[{self.timestamp()}] Retry actualizado a {self.retry_ms}ms")
                except:
                    pass

        if event_id:
            self.ultimo_id = event_id

        try:
            data_json = json.loads(data) if data else {}
        except:
            data_json = {}

        # SIMULACIÓN DE EVENTOS (CLAVE PARA sse.dev)
        self.contador_eventos += 1

        if event == "message":
            if self.contador_eventos % 2 == 0:
                event = "precio-actualizado"
            else:
                event = "stock-critico"

        # MANEJO FUNCIONAL
        if event == "precio-actualizado":
            producto = "producto-demo"

            # sse.dev usa "time"
            precio = data_json.get("time", "N/A")

            print(f"[{self.timestamp()}] Precio actualizado: {producto} → {precio}")

        elif event == "stock-critico":
            print(f"[{self.timestamp()}] STOCK CRÍTICO detectado")

        else:
            print(f"[{self.timestamp()}] Evento: {event}")

    async def ejecutar(self):
        while self.running and self.intentos < self.max_intentos:
            try:
                await self.conectar()
                self.intentos = 0

            except Exception as e:
                print(f"[{self.timestamp()}] Error conexión: {e}")
                self.intentos += 1

                if self.intentos >= self.max_intentos:
                    break

                wait = (self.retry_ms / 1000) * (2 ** (self.intentos - 1))
                print(f"[{self.timestamp()}] Reintentando en {wait:.2f}s...")

                await asyncio.sleep(wait)

        print("Cliente detenido (máx intentos o stop manual).")

    def detener(self):
        print("Deteniendo cliente...")
        self.running = False


async def main():
    url = "https://sse.dev/test"

    receptor = ReceptorAlertas(url)

    try:
        await receptor.ejecutar()
    except KeyboardInterrupt:
        receptor.detener()


if __name__ == "__main__":
    asyncio.run(main())