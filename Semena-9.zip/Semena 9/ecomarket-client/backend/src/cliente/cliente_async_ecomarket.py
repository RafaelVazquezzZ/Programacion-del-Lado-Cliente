import asyncio
import aiohttp
from url_builder import URLBuilder
from cliente.excepciones import APIError
from cliente.coordinador_async import cargar_con_prioridad
from validadores import (
    validar_producto,
    validar_lista_productos,
    ValidationError
)

BASE_URL = "http://localhost:3000"
TIMEOUT = aiohttp.ClientTimeout(total=5)

builder = URLBuilder(BASE_URL)

# ================= EXCEPCIONES ORIGINALES =================

class RecursoNoEncontrado(APIError):
    pass

class ConflictoRecurso(APIError):
    pass


# ================= GET LISTAR =================

async def listar_productos(session, categoria=None):
    try:
        url = f"{BASE_URL}/productos"

        if categoria:
            url += f"?categoria={categoria}"

        async with session.get(url) as resp:

            if resp.status == 404:
                raise RecursoNoEncontrado()

            if resp.status >= 400:
                raise APIError(f"HTTP {resp.status}")

            data = await resp.json()

            if not isinstance(data, list):
                raise APIError("Respuesta inválida")

            return data

    except asyncio.TimeoutError:
        raise APIError("Timeout")

    except asyncio.CancelledError:
        raise APIError("Cancelado")

    except aiohttp.ClientError:
     raise APIError("Error conexión")

    except RecursoNoEncontrado:
        raise
    except Exception as e:
        raise APIError(str(e))




# ================= GET POR ID =================

async def obtener_producto(session, producto_id):
    url = f"{BASE_URL}/productos/{producto_id}"

    try:
        async with session.get(url) as response:

            if response.status == 404:
                raise RecursoNoEncontrado(f"Producto {producto_id} no existe")

            if response.status >= 400:
                raise APIError(f"Error HTTP {response.status}")

            data = await response.json()
            return data

    except asyncio.TimeoutError:
        raise APIError("Timeout del servidor")

    except aiohttp.ClientError:
        raise APIError("Servidor inalcanzable")


    except asyncio.CancelledError:
        raise APIError("Petición cancelada")

    except ValidationError as ve:
        raise APIError(str(ve))


# ================= POST =================

async def crear_producto(session, datos):
    url = f"{BASE_URL}/productos"

    try:
        async with session.post(url, json=datos) as response:

            if response.status in (200, 201):
                return await response.json()

            if response.status == 409:
                raise ConflictoRecurso("El producto ya existe")

            raise APIError(f"Error creando producto {response.status}")

    except asyncio.TimeoutError:
        raise APIError("Timeout creando producto")

    except aiohttp.ClientError:
        raise APIError("Servidor inalcanzable")

    except asyncio.CancelledError:
        raise APIError("Creación cancelada")


# ================= PUT =================

async def actualizar_producto_total(session, producto_id, datos):
    url = f"{BASE_URL}/productos/{producto_id}"

    try:
        async with session.put(url, json=datos) as response:

            if response.status == 200:
                return await response.json()

            if response.status == 404:
                raise RecursoNoEncontrado(f"Producto {producto_id} no existe")

            if response.status == 409:
                raise ConflictoRecurso("Conflicto al actualizar")

            raise APIError(f"Error PUT {response.status}")

    except asyncio.TimeoutError:
        raise APIError("Timeout PUT")

    except aiohttp.ClientError:
        raise APIError("Servidor inalcanzable")


    except asyncio.CancelledError:
        raise APIError("PUT cancelado")


# ================= PATCH =================

async def actualizar_producto_parcial(session, producto_id, campos):
    url = f"{BASE_URL}/productos/{producto_id}"

    try:
        async with session.patch(url, json=campos) as response:

            if response.status == 200:
                return await response.json()

            if response.status == 404:
                raise RecursoNoEncontrado(f"Producto {producto_id} no existe")

            if response.status == 409:
                raise ConflictoRecurso("Conflicto PATCH")

            raise APIError(f"Error PATCH {response.status}")

    except asyncio.TimeoutError:
        raise APIError("Timeout PATCH")

    except aiohttp.ClientError:
        raise APIError("Servidor inalcanzable")


    except asyncio.CancelledError:
        raise APIError("PATCH cancelado")


# ================= DELETE =================

async def eliminar_producto(session, producto_id):
    url = f"{BASE_URL}/productos/{producto_id}"

    try:
        async with session.delete(url) as response:

            if response.status == 204:
                return True

            if response.status == 404:
                raise RecursoNoEncontrado(f"Producto {producto_id} no existe")

            raise APIError(f"Error DELETE {response.status}")

    except asyncio.TimeoutError:
        raise APIError("Timeout DELETE")

    except aiohttp.ClientError:
        raise APIError("Servidor inalcanzable")


    except asyncio.CancelledError:
        raise APIError("DELETE cancelado")


# ================= DASHBOARD =================

async def obtener_categorias(session):
    try:
        async with session.get(f"{BASE_URL}/categorias") as r:

            if r.status >= 400:
                raise APIError(f"Error categorias {r.status}")

            return await r.json()

    except Exception as e:
        raise APIError(str(e))



async def obtener_perfil(session):
    try:
        async with session.get(f"{BASE_URL}/perfil") as r:

            if r.status >= 400:
                raise APIError(f"Error perfil {r.status}")

            return await r.json()

    except Exception as e:
        raise APIError(str(e))



def _procesar_resultados(resultados):
    nombres = ["productos", "categorias", "perfil"]

    data = {}
    errores = {}

    for nombre, r in zip(nombres, resultados):
        if isinstance(r, Exception):
            errores[nombre] = str(r)
        else:
            data[nombre] = r

    return {"data": data, "errores": errores}


async def cargar_dashboard():
    async with aiohttp.ClientSession() as session:

        tareas = {
            "productos": listar_productos(session),
            "categorias": obtener_categorias(session),
            "perfil": obtener_perfil(session)
        }

        resultados = await asyncio.gather(
            *tareas.values(),
            return_exceptions=True
        )

        data = {}
        errores = {}

        for key, res in zip(tareas.keys(), resultados):
            if isinstance(res, Exception):
                errores[key] = str(res)
            else:
                data[key] = res

        return {
            "data": data,
            "errores": errores
        }



# ================= CREAR MULTIPLES =================
async def crear_multiples_productos(productos, limite=5):

    semaphore = asyncio.Semaphore(limite)

    async with aiohttp.ClientSession() as session:

        async def crear_uno(producto):
            async with semaphore:
                return await crear_producto(session, producto)

        tareas = [crear_uno(p) for p in productos]

        resultados = await asyncio.gather(
            *tareas,
            return_exceptions=True
        )

    creados = []
    fallidos = []

    for producto, res in zip(productos, resultados):
        if isinstance(res, Exception):
            fallidos.append(producto)
        else:
            creados.append(res)

    return creados, fallidos


# ================= Test simulando diferentes escenarios ================= 
async def main():
    async with aiohttp.ClientSession() as session:
        await cargar_con_prioridad(session)

if __name__ == "__main__":
    asyncio.run(main())