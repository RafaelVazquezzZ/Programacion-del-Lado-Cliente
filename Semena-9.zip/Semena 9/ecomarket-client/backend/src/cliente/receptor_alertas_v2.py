import asyncio
import httpx
import json
from datetime import datetime

# OBSERVABLE ADAPTADO

class Observable:
    def __init__(self):
        self._observadores = []

    def suscribir(self, obs):
        self._observadores.append(obs)

    def notificar(self, tipo_evento, datos):
        for obs in self._observadores:
            try:
                obs(tipo_evento, datos)
            except Exception as e:
                print(f"[WARN] Error en suscriptor: {e}")

# RECEPTOR SSE v2
class ReceptorAlertas(Observable):

    def __init__(self, url):
        super().__init__()
        self.url = url
        self.ultimo_id = None
        self.retry_ms = 3000
        self.running = True
        self.intentos = 0
        self.max_intentos = 5
        self.contador_eventos = 0

    def timestamp(self):
        return datetime.now().strftime("%H:%M:%S")

    async def conectar(self):
        headers = {"Accept": "text/event-stream"}

        if self.ultimo_id:
            headers["Last-Event-ID"] = self.ultimo_id

        print(f"[{self.timestamp()}] Conectando...")

        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            async with client.stream("GET", self.url, headers=headers) as response:

                buffer = []

                async for line in response.aiter_lines():

                    self.contador_eventos += 1

                    # Simulación de caída real
                    if self.contador_eventos == 5:
                        raise httpx.ReadError("Simulación corte stream")

                    if line == "":
                        if buffer:
                            await self.procesar_evento(buffer)
                            buffer = []
                    else:
                        buffer.append(line)

    async def procesar_evento(self, buffer):
        event = "message"
        data = ""

        for line in buffer:
            if line.startswith("event:"):
                event = line.replace("event:", "").strip()
            elif line.startswith("data:"):
                data += line.replace("data:", "").strip()

        try:
            data_json = json.loads(data) if data else {}
        except:
            data_json = {}

        # Simulación de tipos de eventos
        if self.contador_eventos % 2 == 0:
            event = "precio-actualizado"
        else:
            event = "stock-critico"

        print(f"[{self.timestamp()}] Evento recibido: {event}")

        self.notificar(event, data_json)

    async def ejecutar(self):
        while self.running and self.intentos < self.max_intentos:
            try:
                await self.conectar()
                self.intentos = 0

            except Exception as e:
                print(f"[{self.timestamp()}] Error conexión: {e}")
                self.intentos += 1

                wait = (self.retry_ms / 1000) * (2 ** (self.intentos - 1))
                print(f"[{self.timestamp()}] Reintentando en {wait:.2f}s...")
                await asyncio.sleep(wait)

    def detener(self):
        self.running = False

# SUSCRIPTORES (FUNCIONES)

tabla_precios = {}
auditoria = []

def ActualizadorPreciosUI(tipo, datos):
    if tipo == "precio-actualizado":
        precio = datos.get("now", "N/A")
        tabla_precios["producto-demo"] = precio
        print(f"[UI] Tabla actualizada → {tabla_precios}")


def AlertaStockCritico(tipo, datos):
    if tipo == "stock-critico":
        print("[ALERTA] STOCK CRÍTICO - URGENTE")


def RegistradorAuditoria(tipo, datos):
    registro = {
        "timestamp": datetime.now().strftime("%H:%M:%S"),
        "evento": tipo,
        "datos": datos
    }
    auditoria.append(registro)
    print(f"[AUDITORIA] Evento registrado")


# SUSCRIPTOR QUE FALLA (para evidencia)
def SuscriptorConFallo(tipo, datos):
    if tipo == "stock-critico":
        raise Exception("Fallo simulado en suscriptor")



async def main():
    url = "https://sse.dev"

    receptor = ReceptorAlertas(url)

    # Suscribir funciones
    receptor.suscribir(ActualizadorPreciosUI)
    receptor.suscribir(AlertaStockCritico)
    receptor.suscribir(RegistradorAuditoria)
    receptor.suscribir(SuscriptorConFallo)

    await receptor.ejecutar()


if __name__ == "__main__":
    asyncio.run(main())