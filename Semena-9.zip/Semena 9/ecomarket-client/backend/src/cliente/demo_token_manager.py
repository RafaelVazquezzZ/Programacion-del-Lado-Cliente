from token_manager import TokenManager, ApiClient

import time
import asyncio

def simulate_api_flow():
    print("\n===== LOGIN SIMULADO =====")

    tm = TokenManager()
    client = ApiClient(tm)

    fake_token = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJsubjI6InVzZXJfMSIsImV4cCI6MjAwMDAwMDAwMH0."
        "firma"
    )

    tm.store_tokens(fake_token, "refresh_token_demo")
    print(" Tokens almacenados\n")

    print("===== REQUEST INICIAL =====")
    print(" GET /api/ecomarket/precios")

    response = client.auth_request(
        "GET",
        "http://localhost:8000/api/ecomarket/precios"
    )

    if response.status_code == 401:
        print("401 detectado → iniciando refresh")

    print("\n===== FLUJO DE REFRESH =====")
    print(" Refreshing token...")

    time.sleep(1) 

    print(" Refresh exitoso")
    print(" Reintentando request original...")

    time.sleep(1)

    print(" Request exitoso (200 OK)")

    print("\n===== LOGOUT =====")
    tm.logout()
    print(" Sesión cerrada correctamente")


if __name__ == "__main__":
    simulate_api_flow()