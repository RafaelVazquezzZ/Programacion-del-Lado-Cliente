import base64
import json
import time
import aiohttp
import asyncio

def decode_payload(token):
    header, payload, signature = token.split('.')

    payload += '=' * (-len(payload) % 4)
    payload = payload.replace('-', '+').replace('_', '/')

    decoded = base64.b64decode(payload)
    data = json.loads(decoded)

    now = int(time.time())
    remaining = data['exp'] - now

    print("Minutos restantes:", remaining // 60)

    if remaining <= 0:
        print("El token ya expiró")
    elif remaining < 300:
        print("El token expira en menos de 5 minutos")
    else:
        print("Token válido")

    return data 

token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyXzQ1NiIsImVtYWlsIjoiYW5hQGVjb21hcmtldC5teCIsInJvbGUiOiJvcGVyYXRvciIsImV4cCI6MTcxNDAwMDAwMCwiaWF0IjoxNzEzOTk5MTAwfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
decode_payload(token)