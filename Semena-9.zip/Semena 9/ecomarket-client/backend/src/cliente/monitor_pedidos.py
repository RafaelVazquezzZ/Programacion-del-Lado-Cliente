"""
DECISIONES DE DISEÑO — Cliente EcoMarket / Hito 1
==================================================

TIMEOUT_HTTP = 5s
  → Trade-off: Si es muy bajo, puede cortar peticiones válidas; si es muy alto, el usuario espera demasiado.
    Decisión: 5s permite fallar rápido y mantener una experiencia ágil.

INTERVALO_POLLING_BASE = 5s (máx 30s)
  → Trade-off: Mayor consumo de red por múltiples peticiones vs simplicidad de implementación.
    Decisión: Se usa short polling con backoff para balancear carga y frecuencia de actualización.

REINTENTOS_MAX = 0 (manual por usuario)
  → Trade-off: Menor resiliencia automática vs evitar saturación del servidor y bucles.
    Decisión: Se deja el control al usuario para reintentar.

PATRON_OBSERVER = Implementado (2 observadores)
  → Trade-off: Más estructura de código vs alta escalabilidad.
    Decisión: Permite agregar nuevos observadores sin modificar el monitor.

MEJORA_PROPUESTA:
  Reutilizar ClientSession en lugar de crear una por petición para mejorar eficiencia.

Resumen de la IA validado sin correcciones.
"""

import asyncio
import aiohttp

BASE_URL = "http://localhost:3000"
TIMEOUT = aiohttp.ClientTimeout(total=5)
INTERVALO_BASE = 5


# OBSERVER

class Observador:
    def actualizar(self, datos):
        pass


class Observable:
    def __init__(self):
        self._observadores = []

    def suscribir(self, obs):
        self._observadores.append(obs)

    def _notificar(self, datos):
        for obs in self._observadores:
            obs.actualizar(datos)


# MONITOR PEDIDOS

class MonitorPedidos(Observable):

    def __init__(self):
        super().__init__()
        self.ejecutando = False
        self.intervalo_actual = INTERVALO_BASE
        self.ultimo_estado = None

    async def _consultar_pedidos(self):
        try:
            async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
                async with session.get(f"{BASE_URL}/productos") as resp:

                    if resp.status == 200:
                        data = await resp.json()
                        pedidos = []
                        for p in data:
                            pedidos.append({
                                "id": str(p["id"]),
                                "cliente": p["nombre"],
                                "status": "RETRASADO" if p["precio"] > 100 else "PENDIENTE"
                            })

                        return pedidos

                    elif resp.status == 304:
                        return None

                    elif resp.status >= 500:
                        print("Error servidor (5xx)")
                        return None

                    elif resp.status >= 400:
                        print("Error cliente (4xx)")
                        return None

        except asyncio.TimeoutError:
            print("Timeout consultando productos")
            return None

        except aiohttp.ClientError:
            print("Error de conexión")
            return None

        except Exception as e:
            print("Error inesperado:", e)
            return None

    async def iniciar(self):
        self.ejecutando = True

        while self.ejecutando:

            pedidos = await self._consultar_pedidos()

            if pedidos is not None:

                if pedidos != self.ultimo_estado:
                    print("Cambios detectados en pedidos")
                    self._notificar(pedidos)
                    self.ultimo_estado = pedidos
                    self.intervalo_actual = INTERVALO_BASE

                else:
                    print("Sin cambios en pedidos")
                    self.intervalo_actual = min(
                        self.intervalo_actual + 5, 30
                    )

            else:
                # fallo → backoff
                self.intervalo_actual = min(
                    self.intervalo_actual + 5, 30
                )

            await asyncio.sleep(self.intervalo_actual)

    def detener(self):
        self.ejecutando = False


# OBSERVADORES

class ObservadorPedidosUI(Observador):

    def actualizar(self, pedidos):
        print("\nPedidos actuales:")
        for p in pedidos:
            print(f"{p['id']} - {p['cliente']} - {p['status']}")


class ObservadorPedidosCriticos(Observador):

    def actualizar(self, pedidos):
        for p in pedidos:
            if p["status"] == "RETRASADO":
                print(f"🚨 ALERTA: Pedido retrasado {p['id']}")

async def main():
    monitor = MonitorPedidos()

    # Crear observadores
    ui = ObservadorPedidosUI()
    critico = ObservadorPedidosCriticos()

    # Suscribir
    monitor.suscribir(ui)
    monitor.suscribir(critico)

    # Iniciar monitor (corre 30 segundos)
    tarea = asyncio.create_task(monitor.iniciar())

    await asyncio.sleep(30)

    monitor.detener()
    await tarea


if __name__ == "__main__":
    asyncio.run(main())