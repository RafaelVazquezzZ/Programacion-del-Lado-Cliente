import asyncio
import pytest
import pytest_asyncio
import aiohttp
from aioresponses import aioresponses

from cliente.cliente_async_ecomarket import (
    listar_productos,
    obtener_producto,
    crear_producto,
    actualizar_producto_total,
    actualizar_producto_parcial,
    eliminar_producto,
    cargar_dashboard,
    crear_multiples_productos,
    APIError,
    RecursoNoEncontrado,
    ConflictoRecurso,
    BASE_URL
)

# =========================================================
# FIXTURE SESSION
# =========================================================

@pytest_asyncio.fixture
async def session():
    async with aiohttp.ClientSession() as session:
        yield session


# =========================================================
# 1️⃣ EQUIVALENCIA FUNCIONAL
# =========================================================

@pytest.mark.asyncio
async def test_listar_productos_ok(session):
    """Debe retornar lista validada"""
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos", payload=[{"id":1,"nombre":"A","precio":10, "categoria": "frutas"}])

        res = await listar_productos(session)

        assert isinstance(res, list)
        assert res[0]["id"] == 1


@pytest.mark.asyncio
async def test_listar_404_lanza_recurso_no_encontrado(session):
    """404 debe mapear a excepción custom"""
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos", status=404)

        with pytest.raises(RecursoNoEncontrado):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_obtener_producto_ok(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos/1",
              payload={"id":1,"nombre":"A","precio":10, "categoria": "frutas"})

        res = await obtener_producto(session, 1)

        assert res["id"] == 1


@pytest.mark.asyncio
async def test_crear_producto_conflicto(session):
    with aioresponses() as m:
        m.post(f"{BASE_URL}/productos", status=409)

        with pytest.raises(ConflictoRecurso):
            await crear_producto(session, {"id":1})


@pytest.mark.asyncio
async def test_delete_ok(session):
    with aioresponses() as m:
        m.delete(f"{BASE_URL}/productos/1", status=204)

        res = await eliminar_producto(session, 1)

        assert res is True


# =========================================================
# 2️⃣ CONCURRENCIA
# =========================================================

@pytest.mark.asyncio
async def test_gather_3_ok(session):
    with aioresponses() as m:
        for i in range(3):
            m.get(f"{BASE_URL}/productos/{i}",
                  payload={"id":i,"nombre":"X","precio":1})

        tareas = [obtener_producto(session,i) for i in range(3)]

        await asyncio.gather(*tareas, return_exceptions=True)



@pytest.mark.asyncio
async def test_gather_con_error_return_exceptions(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos/1", payload={"id":1,"nombre":"A","precio":1, "categoria": "frutas"})
        m.get(f"{BASE_URL}/productos/2", status=500)

        tareas = [
            obtener_producto(session,1),
            obtener_producto(session,2)
        ]

        res = await asyncio.gather(*tareas, return_exceptions=True)

        assert any(isinstance(r, Exception) for r in res)


@pytest.mark.asyncio
async def test_gather_sin_return_exceptions(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos/1", status=500)

        with pytest.raises(APIError):
            await asyncio.gather(
                obtener_producto(session,1)
            )


@pytest.mark.asyncio
async def test_dashboard_una_fuente_falla():
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos", payload=[])
        m.get(f"{BASE_URL}/categorias", payload=[])
        m.get(f"{BASE_URL}/perfil", status=500)

        res = await cargar_dashboard()

        assert "perfil" in res["errores"]


@pytest.mark.asyncio
async def test_crear_multiples_respeta_semaforo():
    """Si esto falla suele ser bug de concurrencia"""
    productos = [{"id":i} for i in range(10)]

    with aioresponses() as m:
        m.post(
            f"{BASE_URL}/productos",
            payload={"ok": True},
            repeat=True
        )
        
        creados, fallidos = await crear_multiples_productos(productos)

        assert len(creados) == 10


# =========================================================
# 3️⃣ TIMEOUT Y CANCELACIÓN
# =========================================================

@pytest.mark.asyncio
async def test_timeout_listar(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos",
              exception=asyncio.TimeoutError())

        with pytest.raises(APIError):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_timeout_crear(session):
    with aioresponses() as m:
        m.post(f"{BASE_URL}/productos",
               exception=asyncio.TimeoutError())

        with pytest.raises(APIError):
            await crear_producto(session, {})


@pytest.mark.asyncio
async def test_cancelled_transforma_apierror(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos",
              exception=asyncio.CancelledError())

        with pytest.raises(APIError):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_dashboard_timeout_global():
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(cargar_dashboard(), timeout=0.01)


@pytest.mark.asyncio
async def test_crear_multiples_no_crashea_si_falla():
    productos = [{"id":1}]

    with aioresponses() as m:
        m.post(f"{BASE_URL}/productos", status=500)

        creados, fallidos = await crear_multiples_productos(productos)

        assert len(fallidos) == 1


# =========================================================
# 4️⃣ EDGE CASES
# =========================================================

@pytest.mark.asyncio
async def test_todas_fallan_dashboard():
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos", status=500)
        m.get(f"{BASE_URL}/categorias", status=500)
        m.get(f"{BASE_URL}/perfil", status=500)

        res = await cargar_dashboard()

        assert len(res["errores"]) == 3


@pytest.mark.asyncio
async def test_conexion_cortada(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos",
              exception=aiohttp.ClientConnectionError())

        with pytest.raises(APIError):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_respuesta_despues_timeout(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos",
              exception=asyncio.TimeoutError())

        with pytest.raises(APIError):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_dos_requests_mismo_endpoint(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos?categoria=a", payload=[1])
        m.get(f"{BASE_URL}/productos?categoria=b", payload=[2])

        r1 = await listar_productos(session, categoria="a")
        r2 = await listar_productos(session, categoria="b")

        assert r1 != r2


@pytest.mark.asyncio
async def test_dashboard_siempre_retorna_diccionario():
    res = await cargar_dashboard()
    assert "data" in res
    assert "errores" in res


# =========================================================
# ⭐ TESTS EXTRA PROPIOS
# =========================================================

@pytest.mark.asyncio
async def test_validacion_lista_invalida(session):
    with aioresponses() as m:
        m.get(f"{BASE_URL}/productos", payload="mal")

        with pytest.raises(APIError):
            await listar_productos(session)


@pytest.mark.asyncio
async def test_patch_conflicto(session):
    with aioresponses() as m:
        m.patch(f"{BASE_URL}/productos/1", status=409)

        with pytest.raises(ConflictoRecurso):
            await actualizar_producto_parcial(session,1,{})
