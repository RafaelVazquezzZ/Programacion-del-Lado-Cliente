import pytest
import sys
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_PATH = os.path.join(BASE_DIR, "src")

sys.path.insert(0, SRC_PATH)

from validadores import validar_producto, ValidationError

def test_precio_nan():
    producto = {
        "id": 1,
        "nombre": "Miel",
        "precio": float("nan"),
        "categoria": "miel"
    }

    with pytest.raises(ValidationError, match="precio"):
        validar_producto(producto)

def test_precio_negativo():
    producto = {
        "id": 2,
        "nombre": "Manzana",
        "precio": -10,
        "categoria": "frutas"
    }

    with pytest.raises(ValidationError, match="precio"):
        validar_producto(producto)

def test_categoria_invalida():
    producto = {
        "id": 3,
        "nombre": "Producto raro",
        "precio": 20,
        "categoria": "electronica"
    }

    with pytest.raises(ValidationError, match="categoria"):
        validar_producto(producto)

def test_falta_nombre():
    producto = {
        "id": 4,
        "precio": 15,
        "categoria": "verduras"
    }

    with pytest.raises(ValidationError, match="nombre"):
        validar_producto(producto)

def test_productor_invalido():
    producto = {
        "id": 5,
        "nombre": "Queso",
        "precio": 50,
        "categoria": "lacteos",
        "productor": {
            "id": "uno",
            "nombre": 123
        }
    }

    with pytest.raises(ValidationError, match="productor"):
        validar_producto(producto)