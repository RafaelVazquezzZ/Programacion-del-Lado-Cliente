import sys
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_PATH = os.path.join(BASE_DIR, "src")
sys.path.insert(0, SRC_PATH)

import time

from cliente.cliente_ecomarket import listar_productos

def medir_sync():
    inicio = time.perf_counter()

    productos = listar_productos()

    fin = time.perf_counter()

    print("\n=== RESULTADO DASHBOARD SYNC ===")
    print(productos)

    print(f"\n⏱ Tiempo SYNC: {fin - inicio:.4f} segundos")


if __name__ == "__main__":
    medir_sync()
