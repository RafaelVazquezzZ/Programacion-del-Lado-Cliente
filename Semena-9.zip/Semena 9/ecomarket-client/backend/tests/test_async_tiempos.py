import sys
import os
import pytest

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_PATH = os.path.join(BASE_DIR, "src")

sys.path.insert(0, SRC_PATH)

print("SRC_PATH agregado:", SRC_PATH)
print("sys.path:", sys.path[:3])

import asyncio
import time

from cliente.cliente_async_ecomarket import cargar_dashboard
from cliente.cliente_async_ecomarket import crear_multiples_productos

productos = [
    {
        "nombre": f"Producto {i}",
        "precio": 10 + i,
        "categoria": "frutas"
    }
    for i in range(20)
]

async def medir_async():
    inicio = time.perf_counter()

    resultado = await cargar_dashboard()

    fin = time.perf_counter()

    print("\n=== RESULTADO DASHBOARD ASYNC ===")
    print(resultado)

    print(f"\n⏱ Tiempo ASYNC: {fin - inicio:.4f} segundos")

@pytest.mark.asyncio
async def test():
    inicio = time.perf_counter()

    creados, fallidos = await crear_multiples_productos(productos)

    fin = time.perf_counter()

    print("Creados:", len(creados))
    print("Fallidos:", len(fallidos))
    print("Tiempo:", fin - inicio)

if __name__ == "__main__":
    asyncio.run(medir_async())
