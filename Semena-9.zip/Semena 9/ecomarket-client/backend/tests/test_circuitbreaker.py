import sys
import os
import asyncio

# =========================================================
# AGREGA /src AL PATH
# =========================================================

sys.path.append(
    os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            "..",
            "src"
        )
    )
)

from cliente.circuit_breaker import (
    CircuitBreaker,
    EstadoCircuito,
    CircuitOpenError,
    ServerFailureError,
    ClientFailureError
)


# =========================================================
# MOCK SERVIDOR
# =========================================================

class MockServidor:

    def __init__(self):

        self.modo = "normal"

        self.peticiones_recibidas = 0

    async def get(self, path):

        self.peticiones_recibidas += 1

        await asyncio.sleep(0.05)

        if self.modo == "normal":

            return {
                "ok": True,
                "path": path
            }

        elif self.modo == "fallo_503":

            raise ServerFailureError(
                "503 Service Unavailable"
            )

        elif self.modo == "401":

            raise ClientFailureError(
                "401 Unauthorized"
            )

        else:

            raise Exception(
                "Modo inválido"
            )


# =========================================================
# CASO 1
# =========================================================

async def test_caso1(cb, mock):

    print("\n--- CASO 1 ---")

    mock.modo = "normal"

    for _ in range(10):

        await cb.ejecutar(
            mock.get,
            "/api/inventario"
        )

    assert cb.estado == EstadoCircuito.CERRADO

    assert cb._fallos_consecutivos == 0

    print("✅ CASO 1 PASADO")


# =========================================================
# CASO 2
# =========================================================

async def test_caso2(cb, mock):

    print("\n--- CASO 2 ---")

    cb._estado = EstadoCircuito.CERRADO
    cb._fallos_consecutivos = 0

    mock.modo = "fallo_503"

    for _ in range(cb._umbral_fallos - 1):

        try:

            await cb.ejecutar(
                mock.get,
                "/api/inventario"
            )

        except ServerFailureError:
            pass

    assert cb.estado == EstadoCircuito.CERRADO

    try:

        await cb.ejecutar(
            mock.get,
            "/api/inventario"
        )

    except ServerFailureError:
        pass

    assert cb.estado == EstadoCircuito.ABIERTO

    try:

        await cb.ejecutar(
            mock.get,
            "/api/inventario"
        )

    except CircuitOpenError:

        print(
            "✅ CircuitOpenError correcto"
        )

    print("✅ CASO 2 PASADO")


# =========================================================
# CASO 3
# =========================================================

async def test_caso3(cb, mock):

    print("\n--- CASO 3 ---")

    cb._estado = EstadoCircuito.CERRADO
    cb._fallos_consecutivos = 0

    mock.modo = "401"

    for _ in range(cb._umbral_fallos + 5):

        try:

            await cb.ejecutar(
                mock.get,
                "/api/inventario"
            )

        except ClientFailureError:
            pass

    assert cb.estado == EstadoCircuito.CERRADO

    assert cb._fallos_consecutivos == 0

    print("✅ CASO 3 PASADO")


# =========================================================
# CASO 4
# =========================================================

async def test_caso4(cb, mock):

    print("\n--- CASO 4 ---")

    cb._estado = EstadoCircuito.CERRADO
    cb._fallos_consecutivos = 0

    mock.modo = "fallo_503"

    for _ in range(cb._umbral_fallos):

        try:

            await cb.ejecutar(
                mock.get,
                "/api/inventario"
            )

        except:
            pass

    assert cb.estado == EstadoCircuito.ABIERTO

    print("Esperando timeout...")

    await asyncio.sleep(
        cb._timeout_apertura + 0.1
    )

    assert cb.estado == EstadoCircuito.SEMIABIERTO

    print("✅ CASO 4 PASADO")


# =========================================================
# CASO 5
# =========================================================

async def test_caso5(cb, mock):

    print("\n--- CASO 5 ---")

    mock.modo = "normal"

    await cb.ejecutar(
        mock.get,
        "/api/inventario"
    )

    assert cb.estado == EstadoCircuito.CERRADO

    assert cb._fallos_consecutivos == 0

    print("✅ CASO 5 PASADO")


# =========================================================
# CASO 6
# =========================================================

async def test_caso6(cb, mock):

    print("\n--- CASO 6 ---")

    cb._estado = EstadoCircuito.CERRADO
    cb._fallos_consecutivos = 0

    mock.modo = "fallo_503"

    for _ in range(cb._umbral_fallos):

        try:

            await cb.ejecutar(
                mock.get,
                "/api/inventario"
            )

        except:
            pass

    assert cb.estado == EstadoCircuito.ABIERTO

    await asyncio.sleep(
        cb._timeout_apertura + 0.1
    )

    assert cb.estado == EstadoCircuito.SEMIABIERTO

    try:

        await cb.ejecutar(
            mock.get,
            "/api/inventario"
        )

    except ServerFailureError:
        pass

    assert cb.estado == EstadoCircuito.ABIERTO

    print("✅ CASO 6 PASADO")


# =========================================================
# CASO 7
# =========================================================

async def test_caso7(cb, mock):

    print("\n--- CASO 7 ---")

    cb._estado = EstadoCircuito.CERRADO
    cb._fallos_consecutivos = 0

    mock.modo = "fallo_503"

    for _ in range(cb._umbral_fallos):

        try:

            await cb.ejecutar(
                mock.get,
                "/api/inventario"
            )

        except:
            pass

    await asyncio.sleep(
        cb._timeout_apertura + 0.1
    )

    assert cb.estado == EstadoCircuito.SEMIABIERTO

    mock.modo = "normal"

    mock.peticiones_recibidas = 0

    resultados = await asyncio.gather(

        cb.ejecutar(
            mock.get,
            "/api/inventario"
        ),

        cb.ejecutar(
            mock.get,
            "/api/inventario"
        ),

        cb.ejecutar(
            mock.get,
            "/api/inventario"
        ),

        return_exceptions=True
    )

    exitos = sum(
        1
        for r in resultados
        if not isinstance(r, Exception)
    )

    circuit_errors = sum(
        1
        for r in resultados
        if isinstance(r, CircuitOpenError)
    )

    print(f"Éxitos: {exitos}")

    print(
        f"CircuitOpenErrors: "
        f"{circuit_errors}"
    )

    print(
        f"Peticiones servidor: "
        f"{mock.peticiones_recibidas}"
    )

    assert exitos == 1

    assert circuit_errors == 2

    assert mock.peticiones_recibidas == 1

    print("✅ CASO 7 PASADO")


# =========================================================
# MAIN
# =========================================================

async def main():

    print("\n🚀 INICIANDO TESTS\n")

    cb = CircuitBreaker(

        umbral_fallos=5,

        timeout_apertura=2
    )

    mock = MockServidor()

    await test_caso1(cb, mock)

    await test_caso2(cb, mock)

    await test_caso3(cb, mock)

    await test_caso4(cb, mock)

    await test_caso5(cb, mock)

    await test_caso6(cb, mock)

    await test_caso7(cb, mock)

    print("\n🎉 TODOS LOS TESTS PASARON")


if __name__ == "__main__":

    asyncio.run(main())