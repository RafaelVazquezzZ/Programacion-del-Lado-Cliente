from aiohttp import web
import json

MOCK_ACCESS = "fake_access_token"
MOCK_REFRESH = "fake_refresh_token"

async def handle_login(request):
    return web.json_response({
        "access_token": MOCK_ACCESS,
        "refresh_token": MOCK_REFRESH,
        "expires_in": 900
    })

async def handle_refresh(request):
    body = await request.json()

    if body.get("refresh_token") != MOCK_REFRESH:
        return web.Response(status=401, text="invalid refresh token")

    return web.json_response({
        "access_token": MOCK_ACCESS,
        "expires_in": 900
    })

async def handle_precios(request):
    auth = request.headers.get("Authorization", "")

    if not auth.startswith("Bearer"):
        return web.Response(status=401, text="unauthorized")

    return web.json_response({
        "datos": "lista de precios EcoMarket"
    })


app = web.Application()

app.router.add_post("/api/auth/login", handle_login)
app.router.add_post("/api/auth/refresh", handle_refresh)
app.router.add_get("/api/ecomarket/precios", handle_precios)


if __name__ == "__main__":
    print("Mock server running on http://localhost:8000")
    web.run_app(app, port=8000)