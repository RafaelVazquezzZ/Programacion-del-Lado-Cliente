# Contenido Reto 1 
# Decisiones de diseño — entendidas antes de codificar

## 1. Límite de conexiones en el navegador

Si abro 3 objetos `EventSource` en un navegador hacia el mismo origen, y el límite es 6 conexiones:

- Quedan **3 conexiones libres** para `fetch()`.
- Si se realizan más de 3 peticiones adicionales:
  - No fallan, pero **se encolan (esperan)** hasta que haya una conexión disponible.
  - Esto provoca **lentitud y degradación en la experiencia del usuario**.

---

## 2. Límite de conexiones en Python (`requests`)

- En Python **no existe un límite fijo como el de 6 conexiones** del navegador.
- Sin embargo, las conexiones están limitadas por:
  - Memoria (RAM)
  - Sockets (descriptores de archivo)
  - Puertos TCP
  - Recursos del sistema operativo

**Conclusión:**  
El límite no es artificial, sino **físico (recursos del sistema)**.

---
    
## 3. Manejo de eventos desconocidos en SSE

Si el cliente recibe un evento cuyo tipo (`event:`) no tiene registrado:

- No debe lanzar excepción  
- Debe **ignorar el evento silenciosamente**

**Razón:**
- Permite que el servidor agregue nuevos tipos de eventos sin romper clientes existentes.
- Evita caídas completas de la conexión por eventos no reconocidos.

---

## 4. Modificación de módulos en una conexión SSE multiplexada

Si se desea agregar un nuevo módulo (ej. `"devoluciones"`):

- No se puede modificar la URL de una conexión activa  
- Se debe:
  1. Cerrar la conexión actual
  2. Construir una nueva URL con el nuevo módulo
  3. Reabrir la conexión SSE

**Razón:**
- La URL solo se envía al inicio de la conexión (HTTP GET)
- No existe forma de modificarla en una conexión ya establecida

---

## Síntesis correctiva

- El problema principal del cliente no es solo la cantidad de conexiones, sino que:
  - Las conexiones SSE son **persistentes** y ocupan recursos continuamente.

- En navegadores:
  - Hay un límite de conexiones → provoca colas en `fetch()`

- En Python:
  - El límite depende de los recursos del sistema

- Para eventos:
  - El cliente debe ser **tolerante a cambios** → ignorar eventos desconocidos

- Para multiplexación:
  - Reduce el uso del pool de conexiones
  - Centraliza la lógica en el cliente (EventRouter)
  - Requiere reconexión si cambian los módulos



# Contenido Reto 2

# ClienteSSEMultiplex — EcoMarket

## Decisiones de diseño — entendidas antes de codificar

### 1. Uso de conexiones SSE

Un navegador tiene un límite de aproximadamente 6 conexiones HTTP por origen.
Si se abren múltiples conexiones SSE (una por módulo), estas ocupan permanentemente esos espacios.

Para evitar saturación, se implementa multiplexación:

* Una sola conexión SSE
* Múltiples tipos de eventos en el mismo stream

---

### 2. Multiplexación de eventos

El servidor envía eventos con el campo `event:`.

El cliente:

* Lee ese campo
* Usa un EventRouter para dirigir cada evento a su handler correspondiente

Esto permite manejar múltiples módulos con una sola conexión.

---

### 3. Manejo de eventos desconocidos

Si llega un evento no registrado:

* Se ignora silenciosamente
* No se lanza excepción
* No se cierra la conexión

Esto permite compatibilidad futura.

---

### 4. Last-Event-ID

El cliente guarda el último ID recibido (`ultimo_id`).

Solo se usaría en caso de reconexión para continuar desde ese punto.

---

### 5. Manejo de errores en handlers

Si un handler falla:

* No se detiene el sistema
* Otros handlers siguen funcionando

Esto se logra con try/catch dentro del EventRouter.

---

## Prueba con mock

Se simula un stream SSE con 10 eventos mixtos:

* precio-actualizado
* stock-critico
* pedido-nuevo
* sistema-ping

### Escenario de fallo

El evento #5 genera una excepción en el handler de precio.

Resultado esperado:

* Se registra el error
* El sistema continúa procesando eventos posteriores

---

## Resultado

El cliente:

* Procesa eventos correctamente
* Maneja errores sin colapsar
* Simula multiplexación en una sola conexión SSE

