"""
Monitor de Inventario con Polling Adaptativo y ETag

Trade-offs:
- Polling fijo genera carga constante innecesaria.
- Polling adaptativo reduce consultas cuando no hay cambios.
- Uso de ETag evita transferir datos innecesarios.
- Desventaja: sigue existiendo latencia frente a WebSockets.
"""

import asyncio
import aiohttp
from datetime import datetime

BASE_URL = "http://localhost:3000/productos"
TIMEOUT = aiohttp.ClientTimeout(total=5)


# ================= OBSERVABLE =================

class Observable:
    def __init__(self):
        self._observadores = []

    def suscribir(self, observador):
        self._observadores.append(observador)

    def notificar(self, data):
        for obs in self._observadores:
            try:
                obs.actualizar(data)
            except Exception as e:
                print(f"Error en observador: {e}")


# ================= SERVICIO POLLING =================

class ServicioPolling(Observable):

    def __init__(self):
        super().__init__()
        self.intervalo_actual = 5
        self.intervalo_min = 5
        self.intervalo_max = 60
        self.ultimo_etag = None
        self._activo = False

    async def _consultar(self):

        headers = {}
        if self.ultimo_etag:
            headers["If-None-Match"] = self.ultimo_etag

        try:
            async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
                async with session.get(BASE_URL, headers=headers) as resp:

                    if resp.status == 200:
                        data = await resp.json()
                        print("200 OK - Cambios detectados")

                        etag = resp.headers.get("ETag")
                        if etag:
                            self.ultimo_etag = etag

                        self.notificar(data)

                        self.intervalo_actual = max(
                            self.intervalo_min,
                            self.intervalo_actual - 5
                        )

                    elif resp.status == 304:
                        print("304 - Sin cambios")

                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

                    else:
                        print(f"Error HTTP {resp.status}")
                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

        except Exception as e:
            print(f"Error de conexión: {e}")
            self.intervalo_actual = min(
                self.intervalo_max,
                self.intervalo_actual + 5
            )

    async def iniciar(self):
        self._activo = True
        while self._activo:
            await self._consultar()
            await asyncio.sleep(self.intervalo_actual)

    def detener(self):
        self._activo = False


# ================= OBSERVADORES =================

class LoggerObserver:
    def actualizar(self, data):
        print(f"[LOG] {datetime.now()} - Productos actualizados")


class UIObserver:
    def actualizar(self, data):
        print("[UI] Interfaz actualizada con nuevos datos")


class EstadisticasObserver:
    def actualizar(self, data):
        print(f"[STATS] Total productos: {len(data)}")


# ================= MAIN =================

async def main():

    monitor = ServicioPolling()

    monitor.suscribir(LoggerObserver())
    monitor.suscribir(UIObserver())
    monitor.suscribir(EstadisticasObserver())

    await monitor.iniciar()


if __name__ == "__main__":
    asyncio.run(main())