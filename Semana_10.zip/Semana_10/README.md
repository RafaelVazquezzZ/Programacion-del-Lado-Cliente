# EcoMarket Client — Hito 2
## Cliente Resiliente + Circuit Breaker + SSE + JWT

Proyecto final de Programación del Lado Cliente.

Implementación completa de resiliencia cliente para EcoMarket utilizando:

- Circuit Breaker
- JWT + Refresh Token
- SSE Multiplexado
- Cliente HTTP resiliente
- Reconexión SSE
- Tests automatizados
- Mock server para pruebas
- Regresión cruzada
- Pruebas concurrentes

---

# Autor

- Rafael Vázquez

---

# Hito Implementado

## Hito 2 — Cliente Resiliente

Se implementó un cliente robusto capaz de:

- Detectar fallos del backend
- Abrir y cerrar circuitos automáticamente
- Recuperarse tras fallos temporales
- Mantener streams SSE activos
- Manejar JWT y refresh token
- Proteger refresh concurrentes
- Notificar eventos a UI
- Ejecutar pruebas automatizadas de invariantes
- Ejecutar pruebas de regresión cruzada

---

# Tecnologías Utilizadas

| Tecnología | Uso |
|---|---|
| Python 3.12 | Lenguaje principal |
| asyncio | Concurrencia |
| aiohttp | HTTP async + mock server |
| pytest | Testing |
| pytest-asyncio | Tests async |
| SSE | Eventos en tiempo real |
| JWT | Autenticación |

---

# Versiones Utilizadas

## Python

```powershell
python --version
```

Resultado:

```powershell
Python 3.12.10
```

## pip

```powershell
pip --version
```

## pytest

```powershell
pytest --version
```

---

# Estructura del Proyecto

```text
Semana_10/
│
├── Docs/
│   ├── adr_decision_critica.md
│   ├── autopsia_bugs.md
│   ├── bitacora_ia.md
│   ├── checklist_invariantes.md
│   └── tc_cross_regression.md
│
├── ecomarket-client/
│
│   ├── cliente/
│   │   ├── circuit_breaker.py
│   │   ├── cliente_integrado.py
│   │   ├── cliente_robusto.py
│   │   ├── cliente_sse_multiplex.py
│   │   ├── token_manager.py
│   │   ├── demo_resiliencia.py
│   │   ├── demo_resiliencia.log
│   │   ├── test_circuit_breaker.py
│   │   ├── test_tc_x1.py
│   │   ├── test_tc_x2.py
│   │   └── test_tc_x3.py
│
│   ├── mock/
│   │   ├── mock_ecomarket.py
│   │   └── mock_server.py
│
│   └── README.md
│
└── semana10_cliente_aetl_ver2.html
```

---

# Requisitos

## Requisitos de software

- Windows 10/11
- Python 3.12+
- pip
- PowerShell
- VSCode recomendado

---

# Instalación del Proyecto

## 1. Clonar o copiar proyecto

Ubicar el proyecto en:

```text
C:\Semana_10\ecomarket-client
```

---

## 2. Crear entorno virtual

Desde PowerShell:

```powershell
cd C:\Semana_10\ecomarket-client
python -m venv .venv
```

---

## 3. Activar entorno virtual

```powershell
.\.venv\Scripts\Activate.ps1
```

Resultado esperado:

```powershell
(.venv) PS C:\Semana_10\ecomarket-client>
```

---

# Instalación de Dependencias

## Instalar aiohttp

```powershell
pip install aiohttp
```

## Instalar pytest

```powershell
pip install pytest
```

## Instalar pytest-asyncio

```powershell
pip install pytest-asyncio
```

---

# Componentes Implementados

---

## 1. Circuit Breaker

Archivo:

```text
cliente/circuit_breaker.py
```

Funciones principales:

- Estado CERRADO
- Estado ABIERTO
- Estado SEMIABIERTO
- Conteo de fallos consecutivos
- Timeout automático
- Fail fast
- Protección concurrente en semiabierto

---

## 2. Token Manager

Archivo:

```text
cliente/token_manager.py
```

Funciones:

- Gestión de JWT
- Refresh token
- Singleton refresh
- Auth header
- Expiración de token

---

## 3. Cliente Robusto

Archivo:

```text
cliente/cliente_robusto.py
```

Funciones:

- Requests HTTP resilientes
- Integración con Circuit Breaker
- Refresh automático
- Retry controlado
- Manejo de errores 401/403/5xx
- Observadores UI

---

## 4. Cliente SSE Multiplex

Archivo:

```text
cliente/cliente_sse_multiplex.py
```

Funciones:

- Multiplexación SSE
- EventRouter
- Reconexión
- Last-Event-ID
- Streams simulados
- Handlers por tipo

---

## 5. Mock Server

Archivo:

```text
mock/mock_server.py
```

Simula:

- Respuesta 200
- HTTP 503
- Timeout
- HTTP 401
- Refresh token

---

# Ejecución del Mock Server

## Ejecutar mock

```powershell
cd C:\Semana_10\ecomarket-client\mock
python .\mock_server.py
```

Resultado esperado:

```text
[MOCK] Servidor activo en http://localhost:9000
```

---

# Ejecución del Cliente SSE

## Ejecutar SSE multiplexado

```powershell
cd C:\Semana_10\ecomarket-client\cliente
python .\cliente_sse_multiplex.py
```

Resultado esperado:

```text
[ALERTA] Cambio mayor al 5%
[CRITICO] Stock muy bajo
```

---

# Ejecución del Cliente Integrado

```powershell
cd C:\Semana_10\ecomarket-client\cliente
python .\cliente_integrado.py
```

Resultado esperado:

```text
[LOGIN] Token almacenado
[HTTP #1] 200
[HTTP #2] 200
...
[BREAKER] Fail fast
...
Estado final: circuito=CERRADO
```

---

# Ejecución del Demo de Resiliencia

## Ejecutar demo completa

```powershell
cd C:\Semana_10\ecomarket-client\cliente
python .\demo_resiliencia.py
```

---

## Resultado esperado

```text
=== ESCENARIO 1: RESPUESTAS 200 ===

[HTTP #1] 200
[HTTP #2] 200

=== ESCENARIO 2: FALLAS 503 ===

[HTTP ERROR] HTTP 503
[UI] Circuito ABIERTO
[BREAKER] OPEN

=== ESCENARIO 3: RECUPERACION ===

[RECOVERY] 200
Estado final → CB=CERRADO
```

---

# Archivo de Evidencia

## demo_resiliencia.log

Generado automáticamente por:

```text
demo_resiliencia.py
```

Contiene:

- Fallos
- Apertura de circuito
- Recuperación
- Eventos UI
- Logs HTTP

---

# Ejecución de Tests Automatizados

## Tests de invariantes

```powershell
cd C:\Semana_10\ecomarket-client\cliente
pytest test_circuit_breaker.py -v
```

Resultado esperado:

```text
6 passed
```

---

# Invariantes Validados

| Invariante | Estado |
|---|---|
| INV-A1 | PASS |
| INV-A2 | PASS |
| INV-A3 | PASS |
| INV-A4 | PASS |
| INV-B1 | PASS |
| INV-B2 | PASS |
| INV-B3 | PASS |

---

# Tests de Regresión Cruzada

---

## TC-X1

```powershell
python .\test_tc_x1.py
```

Verifica:

- SSE continúa funcionando mientras CB está ABIERTO

Resultado esperado:

```text
OK → El SSE continuó funcionando
```

---

## TC-X2

```powershell
pytest test_tc_x2.py -v
```

Verifica:

- Refresh singleton
- CB en SEMIABIERTO
- Concurrencia

Resultado esperado:

```text
1 passed
```

---

## TC-X3

```powershell
python .\test_tc_x3.py
```

Verifica:

- Reconexión SSE
- Last-Event-ID
- Persistencia de estado

Resultado esperado:

```text
OK → Reconexión SSE conserva Last-Event-ID correctamente.
```

---

# Historial de Desarrollo

## Fase 1

- Implementación inicial del Circuit Breaker
- Estados CERRADO y ABIERTO
- Timeout de recuperación

## Fase 2

- Implementación SSE multiplexado
- EventRouter
- Reconexión SSE

## Fase 3

- Integración JWT
- Refresh token
- ClienteRobusto

## Fase 4

- Mock server resiliente
- Simulación de errores HTTP
- Simulación de timeout

## Fase 5

- Implementación de pruebas automatizadas
- pytest + pytest-asyncio
- Concurrencia async

## Fase 6

- Tests de regresión cruzada
- Integración completa SSE + JWT + CB

## Fase 7

- Demo resiliente final
- Logging
- Evidencias

---

# Problemas Encontrados

## Error WinError 2

Problema:

```text
No se podía crear venv
```

Solución:

- Reparación de Python
- Migración a Python 3.12

---

## Error permisos carpeta

Problema:

```text
No se podían crear archivos en Documents
```

Solución:

- Uso de C:\Semana_10

---

## Error coroutine object is not callable

Problema:

```text
'coroutine' object is not callable
```

Solución:

- Corregir llamada a CircuitBreaker.ejecutar()
- Pasar función async y no coroutine ejecutada

---

# Decisiones Arquitectónicas

## Circuit Breaker separado del TokenManager

Razón:

- Evitar acoplamiento
- Mantener SRP
- Facilitar testing

---

## SSE separado del Circuit Breaker

Razón:

- SSE usa conexión persistente TCP
- CB solo controla requests HTTP

---

# Resultado Final

Se implementó correctamente:

- Cliente resiliente
- Circuit Breaker
- JWT
- Refresh singleton
- SSE multiplexado
- Reconexión
- Mock server
- Tests automatizados
- Regresión cruzada

Todos los invariantes y escenarios obligatorios fueron aprobados.

---

# Autor

Rafael Gil Samaniego Vázquez
Programación del Lado Cliente
Hito 2 — Cliente Resiliente
