import requests
import pytest
import responses
from cliente_ecomarket import (
    crear_producto,
    actualizar_producto_total,
    actualizar_producto_parcial,
    eliminar_producto,
    obtener_producto,
    listar_productos,
    APIError,
    ValidationError  
)

BASE_URL = "http://localhost:3000"


#HAPPY PATH (6)

@responses.activate
def test_listar_productos_ok():
    """Lista productos correctamente"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos",
        json=[{"id": 1, "nombre": "Manzana", "precio": 10, "categoria": "frutas"}],
        status=200
    )

    productos = listar_productos(None, None)
    assert isinstance(productos, list)
    assert productos[0]["id"] == 1


@responses.activate
def test_obtener_producto_ok():
    """Obtiene un producto válido"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        json={"id": 1, "nombre": "Manzana", "precio": 10, "categoria": "frutas"},
        status=200
    )

    producto = obtener_producto(1)
    assert producto["precio"] == 10


@responses.activate
def test_crear_producto_ok():
    """Crea un producto correctamente"""
    responses.add(
        responses.POST,
        f"{BASE_URL}/productos",
        json={"id": 2, "nombre": "Pera", "precio": 15, "categoria": "frutas"},
        status=201
    )

    producto = crear_producto({"nombre": "Pera", "precio": 15, "categoria": "frutas"})
    assert producto["id"] == 2


@responses.activate
def test_actualizar_producto_parcial_ok():
    """PATCH parcial correcto"""
    responses.add(
        responses.PATCH,
        f"{BASE_URL}/productos/1",
        json={"id": 1, "precio": 20},
        status=200
    )

    producto = actualizar_producto_parcial(1, {"precio": 20})
    assert producto["precio"] == 20


@responses.activate
def test_actualizar_producto_total_ok():
    """PUT completo correcto"""
    responses.add(
        responses.PUT,
        f"{BASE_URL}/productos/1",
        json={"id": 1, "nombre": "Manzana Roja", "precio": 25, "categoria": "frutas"},
        status=200
    )

    producto = actualizar_producto_total(1, {
        "nombre": "Manzana Roja",
        "precio": 25,
        "categoria": "frutas"
    })
    assert producto["nombre"] == "Manzana Roja"


@responses.activate
def test_eliminar_producto_ok():
    """Elimina producto correctamente"""
    responses.add(
        responses.DELETE,
        f"{BASE_URL}/productos/1",
        status=204
    )

    assert eliminar_producto(1) is True


#ERRORES HTTP (8)

@responses.activate
def test_crear_producto_datos_invalidos_400():
    """400 Bad Request al crear producto inválido"""
    responses.add(
        responses.POST,
        f"{BASE_URL}/productos",
        status=400
    )

    with pytest.raises(APIError):
        crear_producto({"nombre": "", "precio": -10})


@responses.activate
def test_sin_autorizacion_401():
    """401 Unauthorized"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos",
        status=401
    )

    with pytest.raises(APIError):
        listar_productos(None, None)


@responses.activate
def test_obtener_producto_inexistente_404():
    """404 producto no encontrado"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/999",
        status=404
    )

    with pytest.raises(APIError):
        obtener_producto(999)


@responses.activate
def test_actualizar_producto_inexistente_404():
    """404 al actualizar producto inexistente"""
    responses.add(
        responses.PUT,
        f"{BASE_URL}/productos/999",
        status=404
    )

    with pytest.raises(APIError):
        actualizar_producto_total(999, {})


@responses.activate
def test_eliminar_producto_inexistente_404():
    """404 al eliminar producto inexistente"""
    responses.add(
        responses.DELETE,
        f"{BASE_URL}/productos/999",
        status=404
    )

    with pytest.raises(APIError):
        eliminar_producto(999)


@responses.activate
def test_crear_producto_duplicado_409():
    """409 Conflict producto duplicado"""
    responses.add(
        responses.POST,
        f"{BASE_URL}/productos",
        status=409
    )

    with pytest.raises(APIError):
        crear_producto({"nombre": "Manzana", "precio": 10})


@responses.activate
def test_error_500_servidor():
    """500 Internal Server Error"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        status=500
    )

    with pytest.raises(APIError):
        obtener_producto(1)


@responses.activate
def test_error_503_servicio_no_disponible():
    """503 Service Unavailable"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos",
        status=503
    )

    with pytest.raises(APIError):
        listar_productos(None, None)


#EDGE CASES (6)

@responses.activate
def test_respuesta_vacia_200():
    """200 OK sin body"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        body="",
        status=200
    )

    with pytest.raises(APIError):
        obtener_producto(1)


@responses.activate
def test_content_type_incorrecto():
    """Content-Type text/html"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        body="<html>Error</html>",
        content_type="text/html",
        status=200
    )

    with pytest.raises(APIError):
        obtener_producto(1)


@responses.activate
def test_json_estructura_incorrecta():
    """JSON válido pero sin campos requeridos"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        json={"unexpected": "field"},
        status=200
    )

    with pytest.raises(APIError):
        obtener_producto(1)

@responses.activate
def test_timeout_servidor():
    """Timeout del servidor"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos",
        body=requests.exceptions.Timeout()
    )

    with pytest.raises(APIError):
        listar_productos(None, None)

@responses.activate
def test_precio_como_string():
    """Precio viene como string"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos/1",
        json={"id": 1, "nombre": "Manzana", "precio": "10", "categoria": "frutas"},
        status=200
    )

    with pytest.raises(APIError):
        obtener_producto(1)

@responses.activate
def test_lista_productos_vacia():
    """Lista vacía de productos"""
    responses.add(
        responses.GET,
        f"{BASE_URL}/productos",
        json=[],
        status=200
    )

    productos = listar_productos(None, None)
    assert productos == []


# TESTS EXTRA (2)
@responses.activate
def test_crear_producto_sin_precio():
    """Falta campo obligatorio"""
    responses.add(
        responses.POST,
        f"{BASE_URL}/productos",
        status=400
    )

    with pytest.raises(APIError):
        crear_producto({"nombre": "X"})


@responses.activate
def test_patch_sin_campos():
    """PATCH sin campos"""
    responses.add(
        responses.PATCH,
        f"{BASE_URL}/productos/1",
        status=400
    )

    with pytest.raises(APIError):
        actualizar_producto_parcial(1, {})
