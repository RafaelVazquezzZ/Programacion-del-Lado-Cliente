import requests
from url_builder import URLBuilder
from validadores import (
    validar_producto,
    validar_lista_productos,
    ValidationError
)

BASE_URL = "http://localhost:3000"
TIMEOUT = 5

builder = URLBuilder(BASE_URL)

#Excepciones

class APIError(Exception):
    """Error genérico de la API"""

class RecursoNoEncontrado(APIError):
    """Recurso no encontrado (404)"""

class ConflictoRecurso(APIError):
    """Conflicto de recurso (409)"""


# POST - Crear producto
def crear_producto(datos: dict) -> dict:
    """
    Crea un nuevo producto en EcoMarket.

    Ejemplo:
    >>> crear_producto({
    ...   "nombre": "Manzana",
    ...   "precio": 20,
    ...   "categoria": "frutas"
    ... })
    {'id': 10, 'nombre': 'Manzana', 'precio': 20, 'categoria': 'frutas'}
    """
    url = f"{BASE_URL}/productos"
    headers = {"Content-Type": "application/json"}

    response = requests.post(url, json=datos, headers=headers, timeout=TIMEOUT)

    if response.status_code == 201:
        return response.json()

    if response.status_code == 409:
        raise ConflictoRecurso("El producto ya existe (409 Conflict)")

    raise APIError(f"Error creando producto: {response.status_code} - {response.text}")


# PUT - Actualización total
def actualizar_producto_total(producto_id: int, datos: dict) -> dict:
    """
    Reemplaza completamente un producto existente.

    IMPORTANTE: `datos` debe contener el recurso COMPLETO.

    Ejemplo:
    >>> actualizar_producto_total(1, {
    ...   "nombre": "Manzana Roja",
    ...   "precio": 22,
    ...   "categoria": "frutas"
    ... })
    """
    url = f"{BASE_URL}/productos/{producto_id}"
    headers = {"Content-Type": "application/json"}

    response = requests.put(url, json=datos, headers=headers, timeout=TIMEOUT)

    if response.status_code == 200:
        return response.json()

    if response.status_code == 404:
        raise RecursoNoEncontrado(f"Producto {producto_id} no encontrado")

    if response.status_code == 409:
        raise ConflictoRecurso("Conflicto al actualizar el producto")

    raise APIError(f"Error PUT producto: {response.status_code} - {response.text}")


# PATCH - Actualización parcial
def actualizar_producto_parcial(producto_id: int, campos: dict) -> dict:
    """
    Actualiza parcialmente un producto.

    `campos` contiene SOLO los atributos a modificar.

    Ejemplo:
    >>> actualizar_producto_parcial(1, {"precio": 25})
    """
    url = f"{BASE_URL}/productos/{producto_id}"
    headers = {"Content-Type": "application/json"}

    response = requests.patch(url, json=campos, headers=headers, timeout=TIMEOUT)

    if response.status_code == 200:
        return response.json()

    if response.status_code == 404:
        raise RecursoNoEncontrado(f"Producto {producto_id} no encontrado")

    if response.status_code == 409:
        raise ConflictoRecurso("Conflicto al modificar el producto")

    raise APIError(f"Error PATCH producto: {response.status_code} - {response.text}")


# DELETE - Eliminar producto
def eliminar_producto(producto_id: int) -> bool:
    """
    Elimina un producto por ID.

    Retorna True si se eliminó correctamente.

    Ejemplo:
    >>> eliminar_producto(3)
    True
    """
    url = f"{BASE_URL}/productos/{producto_id}"

    response = requests.delete(url, timeout=TIMEOUT)

    if response.status_code == 204:
        return True

    if response.status_code == 404:
        raise RecursoNoEncontrado(f"Producto {producto_id} no existe")

    raise APIError(f"Error eliminando producto: {response.status_code} - {response.text}")

# GET - Obtener producto por ID
def obtener_producto(id):
    url = f"{BASE_URL}/productos/{id}"
    try:
        response = requests.get(url, timeout=TIMEOUT)
        response.raise_for_status()
        data = response.json()
        return validar_producto(data)
    except ValidationError as ve:
        raise APIError(str(ve))
    except requests.exceptions.Timeout:
        raise APIError("Timeout del servidor")
    except requests.exceptions.RequestException as e:
        raise APIError(str(e))

# GET - Listar productos
def listar_productos(categoria=None, orden=None):
    url = f"{BASE_URL}/productos"
    params = {}
    if categoria: params["categoria"] = categoria
    if orden: params["orden"] = orden

    try:
        response = requests.get(url, params=params, timeout=TIMEOUT)
        response.raise_for_status()
        data = response.json()
        return validar_lista_productos(data)
    except requests.exceptions.Timeout:
        raise APIError("Timeout del servidor")
    except requests.exceptions.RequestException as e:
        raise APIError(str(e))
    except ValidationError as ve:
        raise APIError(str(ve))

