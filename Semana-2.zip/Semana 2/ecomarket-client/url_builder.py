# url_builder.py
from urllib.parse import quote, urlencode, urljoin
from uuid import UUID


class InvalidPathParam(Exception):
    pass


class URLBuilder:
    def __init__(self, base_url: str = ""):
        self.base_url = base_url.rstrip("/") + "/"

    # VALIDACIONES
    def _validate_id(self, value):
        """
        Permite solo int o UUID válido
        """
        if isinstance(value, int):
            return str(value)

        if isinstance(value, str):
            try:
                UUID(value)
                return value
            except ValueError:
                pass

        raise InvalidPathParam(
            f"ID inválido ({value}). Solo se permiten int o UUID."
        )

    # PATH PARAMS SEGUROS
    def build_path(self, *segments):
        """
        Construye un path seguro:
        - Segmentos str → tratados como literales
        - Segmentos int/UUID → validados estrictamente
        """
        safe_segments = []

        for seg in segments:
            if isinstance(seg, (int, str)):
                # Si es int → ID válido
                if isinstance(seg, int):
                    validated = self._validate_id(seg)
                # Si es str, puede ser literal o UUID
                elif isinstance(seg, str):
                    try:
                        validated = self._validate_id(seg)
                    except InvalidPathParam:
                        # Es un literal como "productos"
                        validated = seg

                escaped = quote(str(validated), safe="")
                safe_segments.append(escaped)
            else:
                raise InvalidPathParam(f"Segmento inválido: {seg}")

        path = "/".join(safe_segments)
        return urljoin(self.base_url, path)

    # QUERY STRING SEGURO
    def build_query(self, params: dict):
        """
        Construye un query string seguro
        """
        return urlencode(params, doseq=True, safe="")

    # URL COMPLETA
    def build_url(self, *segments, query_params=None):
        url = self.build_path(*segments)

        if query_params:
            query = self.build_query(query_params)
            url = f"{url}?{query}"

        return url

# TESTS BÁSICOS
if __name__ == "__main__":
    builder = URLBuilder("https://api.ecomarket.com")

    print("URL válida con int:")
    print(builder.build_url("productos", 10))

    print("\nURL válida con UUID:")
    print(builder.build_url("productos", "550e8400-e29b-41d4-a716-446655440000"))

    print("\nQuery seguro:")
    print(
        builder.build_url(
            "productos",
            5,
            query_params={"search": "miel orgánica", "limit": 10}
        )
    )

    print("\nIntento malicioso (path traversal):")
    try:
        builder.build_url("productos", "../../../etc/passwd")
    except Exception as e:
        print("Bloqueado:", e)

    print("\nIntento malicioso (inyección de query):")
    print(
        builder.build_url(
            "productos",
            1,
            query_params={"q": "test&admin=true"}
        )
    )

    print("\nIntento unicode peligroso:")
    try:
        builder.build_url("productos", "１")
    except Exception as e:
        print("Bloqueado:", e)
