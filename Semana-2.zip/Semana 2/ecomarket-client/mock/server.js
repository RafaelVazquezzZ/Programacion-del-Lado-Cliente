import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

let productos = [
  { id: 1, nombre: 'Miel', precio: 120, categoria: 'miel' },
  { id: 2, nombre: 'Café', precio: 90, categoria: 'bebidas' }
];

let nextId = 3;

// GET
app.get('/productos', (req, res) => {
  res.json(productos);
});

// Producto inválido para testing
app.get('/productos/999', (req, res) => {
  res.json({
    id: 999,
    nombre: "Producto roto",
    precio: -100,
    categoria: "frutas"
  });
});

app.get('/productos/:id', (req, res) => {
  const id = Number(req.params.id);
  const producto = productos.find(p => p.id === id);

  if (!producto) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  res.json(producto);
});

// POST
app.post('/productos', (req, res) => {
  const nuevo = req.body;

  // conflicto simple (nombre duplicado)
  if (productos.some(p => p.nombre === nuevo.nombre)) {
    return res.status(409).json({ error: 'Producto duplicado' });
  }

  nuevo.id = nextId++;
  productos.push(nuevo);

  res.status(201).json(nuevo);
});

// PUT (reemplazo total)
app.put('/productos/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = productos.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  productos[index] = { id, ...req.body };
  res.json(productos[index]);
});

// PATCH (parcial)
app.patch('/productos/:id', (req, res) => {
  const id = Number(req.params.id);
  const producto = productos.find(p => p.id === id);

  if (!producto) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  Object.assign(producto, req.body);
  res.json(producto);
});

// DELETE
app.delete('/productos/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = productos.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  productos.splice(index, 1);
  res.status(204).send();
});

// ESCENARIO 3 (caos)
app.get('/caos/truncado', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.write('{ "id": 1, "nombre": "Miel" ');
  res.destroy();
});

app.listen(3000, () => {
  console.log('Mock server en http://localhost:3000');
});
