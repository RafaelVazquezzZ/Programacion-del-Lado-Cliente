import {
  listarProductos,
  obtenerProductoPorId,
  crearProducto,
  fetchWithTimeout 
} from './api.js';

import { validarProducto } from "./validadores.js";

async function cargarProductos() {
  try {
    const productos = await listarProductos();

    productos.forEach(producto => {
      validarProducto(producto);
    });

    console.log("Productos válidos:", productos);
  } catch (error) {
    console.error("Datos inválidos del servidor:", error.message);
  }
}

async function demoListar() {
  try {
    //CORRECION DE ASUMIR ESTRUCTURA (PODIAN SER ARRAYS, LISTAS, ETC.)
    const result = await listarProductos();
    const productos = result?.data ?? result;

    if (!Array.isArray(productos)) {
      throw new Error('Respuesta inesperada del servidor');
    }

    console.log('Productos:');
    productos.forEach(p =>
      console.log(`- ${p.nombre ?? p.title} ($${p.precio ?? 'N/A'})`)
    );
//CORRECION DE CODIGO PARA ERRORES
  } catch (e) {
    console.error('Error listando productos', e);
  }
}

async function demoObtener() {
  let producto;
//AGREGAR EL TRY/CATCH
  try {
    producto = await obtenerProductoPorId(1);
  } catch (e) {
    console.error('Error obteniendo producto con id 1', e);
    return;
  }

  if (!producto) {
    console.warn('Producto no encontrado');
    return;
  }

  console.log('Producto:', producto);
}

async function demoCrear() {
  const productoNuevo = {
    nombre: 'Miel orgánica',
    precio: 150.50,
    categoria: 'miel',
    productor_id: 5
  };

  if (!productoNuevo.nombre || productoNuevo.precio <= 0) {
    console.warn('Datos de producto inválidos');
    return;
  }

 //SOLUCION PARA TOKEN
  const token = localStorage.getItem('token');

  try {
    const response = await crearProducto(productoNuevo, token);

    if (response.status === 201) {
      console.log('Producto creado');
    } else if (response.status === 400) {
      const error = await response.json();
      console.warn('Error:', error.mensaje);
    } else {
      console.warn('Respuesta inesperada:', response.status);
    }

  } catch (e) {
    console.error('Error creando producto', e);
  }
}

//Uso de fetch
fetch("http://localhost:3000/productos/3", {
  method: "PATCH",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    precio: 35
  })
})
.then(res => res.json())
.then(data => console.log("PATCH OK:", data))
.catch(err => console.error(err));


async function escenario3() {
  try {
    const response = await fetchWithTimeout('http://localhost:3000/caos/truncado');
    await response.json(); // 💥 aquí debe romper
  } catch (e) {
    console.error('Escenario 3 activado (respuesta truncada):', e);
  }
}
//Prueba para cuando los productos sean lentos y mostrar el WARN
await fetchWithTimeout('http://localhost:3000/productos-lento');

listarProductos();
demoListar();
demoObtener();
demoCrear();
escenario3();
cargarProductos();
