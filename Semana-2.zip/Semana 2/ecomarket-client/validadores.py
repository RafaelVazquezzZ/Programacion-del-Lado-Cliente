import math
from datetime import datetime

CATEGORIAS_VALIDAS = ["frutas", "verduras", "lacteos", "miel", "conservas"]


class ValidationError(Exception):
    pass


def validar_producto(data: dict) -> dict:
    if not isinstance(data, dict):
        raise ValidationError("El producto debe ser un diccionario")

    #Campos requeridos
    for campo in ["id", "nombre", "precio", "categoria"]:
        if campo not in data:
            raise ValidationError(f"Falta el campo requerido: {campo}")

    #id
    if not isinstance(data["id"], int):
        raise ValidationError("id debe ser entero")

    #nombre 
    if not isinstance(data["nombre"], str):
        raise ValidationError("nombre debe ser string")
    
    # validar precio
    if not isinstance(data["precio"], (int, float)):
        raise ValidationError("El campo precio debe ser numérico")
    
    #precio
    precio = data["precio"]

    if not isinstance(precio, (int, float)):
        raise ValidationError("precio debe ser numérico")

    if math.isnan(precio):
        raise ValidationError("precio no puede ser NaN")

    if precio < 0:
        raise ValidationError("precio no puede ser negativo")

    #categoria
    if not isinstance(data["categoria"], str):
        raise ValidationError("categoria debe ser string")

    if data["categoria"] not in CATEGORIAS_VALIDAS:
        raise ValidationError("categoria inválida")

    #disponible (opcional)
    if "disponible" in data and not isinstance(data["disponible"], bool):
        raise ValidationError("disponible debe ser booleano")

    #descripcion (opcional)
    if "descripcion" in data and not isinstance(data["descripcion"], str):
        raise ValidationError("descripcion debe ser string")

    #productor (opcional) 
    if "productor" in data:
        productor = data["productor"]

        if not isinstance(productor, dict):
            raise ValidationError("productor debe ser un objeto")

        if "id" not in productor or "nombre" not in productor:
            raise ValidationError("productor debe tener id y nombre")

        if not isinstance(productor["id"], int):
            raise ValidationError("productor.id debe ser entero")

        if not isinstance(productor["nombre"], str):
            raise ValidationError("productor.nombre debe ser string")

    # ===== creado_en (opcional)
    if "creado_en" in data:
        try:
            datetime.fromisoformat(
                data["creado_en"].replace("Z", "+00:00")
            )
        except Exception:
            raise ValidationError("creado_en debe estar en formato ISO 8601")

    return data


def validar_lista_productos(data: list) -> list:
    if not isinstance(data, list):
        raise ValidationError("La respuesta no es una lista de productos")

    return [validar_producto(producto) for producto in data]
