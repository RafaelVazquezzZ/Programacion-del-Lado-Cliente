const CATEGORIAS_VALIDAS = ["frutas", "verduras", "lacteos", "miel", "conservas"];

export function validarFechaISO(fecha) {
  return !isNaN(Date.parse(fecha));
}

export function validarProducto(data) {
  if (typeof data !== "object" || data === null) {
    throw new Error("La respuesta no es un objeto JSON");
  }

  const campos = [
    "id", "nombre", "precio",
    "categoria", "productor",
    "disponible", "creado_en"
  ];

  for (const campo of campos) {
    if (!(campo in data)) {
      throw new Error(`Falta el campo requerido: ${campo}`);
    }
  }

  if (!Number.isInteger(data.id)) {
    throw new Error("id debe ser entero");
  }

  if (typeof data.nombre !== "string") {
    throw new Error("nombre debe ser string");
  }

  if (typeof data.precio !== "number" || !Number.isFinite(data.precio)) {
    throw new Error("precio debe ser un número válido");
  }

  if (data.precio <= 0) {
    throw new Error("precio debe ser positivo");
  }

  if (!CATEGORIAS_VALIDAS.includes(data.categoria)) {
    throw new Error("categoria no válida");
  }

  if (typeof data.disponible !== "boolean") {
    throw new Error("disponible debe ser boolean");
  }

  if (!validarFechaISO(data.creado_en)) {
    throw new Error("creado_en no es una fecha ISO válida");
  }

  if (typeof data.productor !== "object" || data.productor === null) {
    throw new Error("productor debe ser un objeto");
  }

  if (!Number.isInteger(data.productor.id)) {
    throw new Error("productor.id debe ser entero");
  }

  if (typeof data.productor.nombre !== "string") {
    throw new Error("productor.nombre debe ser string");
  }

  return true;
}
