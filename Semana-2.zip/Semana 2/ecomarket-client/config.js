export const BASE_URL = 'http://localhost:3000';
export const TIMEOUT_MS = 10000;

// NUEVO
export const LOG_LEVEL =
  import.meta.env?.MODE === 'production'
    ? 'INFO'
    : 'DEBUG';

if (!['DEBUG', 'INFO', 'WARN', 'ERROR'].includes(LOG_LEVEL)) {
  console.warn('LOG_LEVEL inválido, usando INFO');
}