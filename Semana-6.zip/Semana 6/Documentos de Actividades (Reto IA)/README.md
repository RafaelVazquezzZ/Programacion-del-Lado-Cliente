Polling es cuando el cliente pregunta constantemente al servidor si hay cambios,
mientras que SSE permite que el servidor envíe actualizaciones automáticamente
sin que el cliente tenga que hacer nuevas peticiones.