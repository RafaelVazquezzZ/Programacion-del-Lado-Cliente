# AUDITORÍA SSE — Cliente EcoMarket

## ERROR 1 — Caída del stream no detectada correctamente

### Descripción

Inicialmente, el cliente no simulaba correctamente una caída de red, ya que la excepción se lanzaba fuera del flujo de lectura del stream.

### ¿Cómo falla en producción?

El cliente nunca detectaría cortes reales de conexión (socket cerrado, timeout, etc.), por lo que:

* No se activaría la reconexión
* El cliente quedaría “congelado” sin recibir eventos

### Invariante violado

> "Una falla de red debe provocar reconexión automática del cliente"

### Código incorrecto

```python
self.contador_eventos += 1
if self.contador_eventos == 5:
    raise httpx.ReadError("Simulación corte stream")
```

### Código corregido

```python
async for line in response.aiter_lines():
    self.contador_eventos += 1
    if self.contador_eventos == 5:
        raise httpx.ReadError("Simulación corte stream")
```

### Evidencia

```txt
[10:53:51] Error conexión: Simulación corte stream
[10:53:51] Reintentando en 3.00s...
```

---

## ERROR 2 — Excepciones en el handler rompen el flujo

### Descripción

El método `procesar_evento` podía lanzar excepciones que terminaban cerrando la conexión completa.

### ¿Cómo falla en producción?

Un error en datos (JSON mal formado, evento inesperado) provoca:

* Caída total del cliente
* Pérdida de eventos posteriores

### Invariante violado

> "Errores de procesamiento NO deben cerrar la conexión SSE"

### Código incorrecto

```python
await self.procesar_evento(buffer)
```

### Código corregido

```python
async def safe_procesar_evento(self, buffer):
    try:
        await self.procesar_evento(buffer)
    except Exception as e:
        print(f"Error en handler: {e}")
```

### Evidencia

El cliente continúa funcionando después de múltiples eventos:

```txt
[10:54:02] STOCK CRÍTICO detectado
[10:54:04] Precio actualizado: producto-demo → N/A
```

---

## ERROR 3 — Timeout mal configurado para SSE

### Descripción

Se utilizaba un timeout de lectura limitado, lo cual es incompatible con SSE (stream infinito).

### ¿Cómo falla en producción?

* El cliente se desconecta automáticamente aunque el servidor funcione correctamente
* Reconexiones innecesarias

### Invariante violado

> "Una conexión SSE debe permanecer abierta indefinidamente mientras haya datos"

### Código incorrecto

```python
timeout = httpx.Timeout(connect=5.0, read=5.0)
```

### Código corregido

```python
timeout = httpx.Timeout(30.0)
```

### Evidencia

Antes: desconexiones constantes
Después:

```txt
[10:53:49] STATUS: 200
[10:54:10] STOCK CRÍTICO detectado
```

---

## ERROR 4 — Buffer SSE incompleto (pérdida de eventos)

### Descripción

El cliente no procesaba correctamente el último evento si el stream no terminaba con línea vacía.

### ¿Cómo falla en producción?

* Último evento del stream se pierde
* Inconsistencia en datos mostrados

### Invariante violado

> "Todo evento recibido debe ser procesado completamente"

### Código incorrecto

(No existía procesamiento final del buffer)

### Código corregido

```python
if buffer:
    await self.safe_procesar_evento(buffer)
```

### Evidencia

Eventos continuos procesados correctamente:

```txt
[10:54:08] Precio actualizado: producto-demo → N/A
[10:54:10] STOCK CRÍTICO detectado
```

---

# CONCLUSIÓN

El cliente ahora cumple con los principios clave de un sistema SSE robusto:

* Manejo correcto de errores de red
* Aislamiento de errores de procesamiento
* Persistencia de conexión
* Reconexión automática con backoff
* Procesamiento completo de eventos

Se validó cada error mediante ejecución real y evidencia en logs.
