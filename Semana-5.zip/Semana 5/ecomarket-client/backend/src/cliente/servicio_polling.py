import asyncio
import aiohttp

BASE_URL = "http://localhost:3000"
TIMEOUT = aiohttp.ClientTimeout(total=5)


class ServicioPolling:

    def __init__(self, endpoint="/productos"):
        self.endpoint = endpoint
        self.intervalo_actual = 5
        self.intervalo_min = 5
        self.intervalo_max = 60
        self.ultimo_etag = None
        self._activo = False

    async def _consultar(self):
        headers = {}

        # Agregar ETag si existe
        if self.ultimo_etag:
            headers["If-None-Match"] = self.ultimo_etag

        try:
            async with aiohttp.ClientSession(timeout=TIMEOUT) as session:
                async with session.get(
                    f"{BASE_URL}{self.endpoint}",
                    headers=headers
                ) as resp:

                    # Caso cambios detectados
                    if resp.status == 200:

                        print("Cambios detectados")

                        # Guardar nuevo ETag
                        etag = resp.headers.get("ETag")
                        if etag:
                            self.ultimo_etag = etag

                        # Disminuir intervalo
                        self.intervalo_actual = max(
                            self.intervalo_min,
                            self.intervalo_actual - 5
                        )

                    # Caso sin cambios
                    elif resp.status == 304:

                        print("Sin cambios")

                        # Aumentar intervalo
                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

                    # Otros errores HTTP
                    else:
                        print(f"Error HTTP {resp.status}")
                        self.intervalo_actual = min(
                            self.intervalo_max,
                            self.intervalo_actual + 5
                        )

        except Exception as e:
            print(f"Error en polling: {e}")

            # Aumentar intervalo en caso de fallo
            self.intervalo_actual = min(
                self.intervalo_max,
                self.intervalo_actual + 5
            )

    async def iniciar(self):
        self._activo = True

        while self._activo:
            await self._consultar()
            await asyncio.sleep(self.intervalo_actual)

    def detener(self):
        self._activo = False