from aiohttp import web
import asyncio

async def productos(request):
    await asyncio.sleep(1)
    return web.json_response({"productos": ["manzana", "banana"]})

async def categorias(request):
    await asyncio.sleep(8)  # Simula delay largo
    return web.json_response({"categorias": ["frutas", "verduras"]})

async def perfil(request):
    await asyncio.sleep(4)
    return web.Response(status=401)  # Simula no autorizado

async def notificaciones(request):
    await asyncio.sleep(2)
    return web.json_response({"notificaciones": ["nuevo descuento"]})

app = web.Application()
app.add_routes([
    web.get('/productos', productos),
    web.get('/categorias', categorias),
    web.get('/perfil', perfil),
    web.get('/notificaciones', notificaciones)
])

web.run_app(app, port=8000)
